(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const API_BASE = (window.MOON_API_BASE || '').replace(/\/$/, '');
  const state = {
    user: null, csrf: null, page: 'overview', dashboard: null, integrations: null,
    settings: {}, searches: [], leads: [], allLeads: [], filters: {},
    currentResearch: null, currentResearchData: null, pollTimer: null,
    modalLead: null, navToken: 0, introTimer: null,
  };
  const pageMeta = {
    overview: ['Visão geral', 'VISÃO GERAL'], 'new-research': ['Nova prospecção', 'NOVA PROSPECÇÃO'],
    results: ['Resultados', 'RESULTADOS'], saved: ['Leads salvos', 'LEADS SALVOS'],
    clients: ['Clientes qualificados', 'CLIENTES QUALIFICADOS'], history: ['Histórico de pesquisas', 'HISTÓRICO'],
    prompts: ['Prompts para Arena AI', 'ARENA AI'], settings: ['Configurações', 'CONFIGURAÇÕES'],
  };
  const stages = ['Novo lead', 'Lead analisado', 'Contato realizado', 'Aguardando resposta', 'Interessado', 'Reunião ou negociação', 'Cliente fechado', 'Não interessado'];
  const projectStatuses = ['NÃO INICIADO', 'BRIEFING PRONTO', 'PROJETO PREPARADO', 'SITE GERADO'];
  const icons = {
    dashboard: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    radar: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/><path d="m12 12 7-7"/>',
    results: '<path d="M4 19V9m5 10V5m5 14v-7m5 7V3"/>',
    bookmark: '<path d="M6 3h12v18l-6-4-6 4V3Z"/>',
    clients: '<circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2"/><path d="M3 20c0-4 2-7 6-7s6 3 6 7m1-5c3 0 5 2 5 5"/>',
    history: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5m4-1v5l3 2"/>',
    code: '<path d="m8 7-5 5 5 5m8-10 5 5-5 5m-2-13-4 16"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H3v-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3V3h4v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z"/>',
    logout: '<path d="M10 4H4v16h6m5-4 4-4-4-4m4 4H9"/>',
  };

  function icon(name) { return `<svg viewBox="0 0 24 24" aria-hidden="true">${icons[name] || icons.dashboard}</svg>`; }
  function esc(value) { return String(value ?? '—').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
  function safeUrl(value) {
    if (!value) return null;
    try { const url = new URL(value); return ['http:', 'https:'].includes(url.protocol) ? url.href : null; } catch { return null; }
  }
  function externalLink(url, label, className = '') {
    const safe = safeUrl(url);
    return safe ? `<a class="${className}" href="${esc(safe)}" target="_blank" rel="noopener noreferrer">${esc(label)}</a>` : `<span class="${className} disabled">${esc(label)}</span>`;
  }
  function fmtNumber(value) { return value === null || value === undefined ? '—' : Number(value).toLocaleString('pt-BR'); }
  function fmtDate(value, relative = false) {
    if (!value) return '—';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    if (relative) {
      const seconds = (date.getTime() - Date.now()) / 1000;
      const abs = Math.abs(seconds);
      const units = abs < 3600 ? ['minuto', 60] : abs < 86400 ? ['hora', 3600] : ['dia', 86400];
      const amount = Math.max(1, Math.round(abs / units[1]));
      return seconds < 0 ? `há ${amount} ${units[0]}${amount > 1 ? 's' : ''}` : `em ${amount} ${units[0]}${amount > 1 ? 's' : ''}`;
    }
    return date.toLocaleDateString('pt-BR', {day: '2-digit', month: '2-digit', year: 'numeric'});
  }
  function statusBadge(status) {
    if (status === 'VERIFICADO') return '<span class="badge badge-verified">VERIFICADO</span>';
    if (status === 'PARCIALMENTE VERIFICADO') return '<span class="badge badge-partial">PARCIAL</span>';
    if (status === 'NÃO QUALIFICADO') return '<span class="badge badge-failed">NÃO QUALIFICADO</span>';
    if (status === 'INDISPONÍVEL') return '<span class="badge badge-partial">INDISPONÍVEL</span>';
    if (status === 'INCONSISTENTE') return '<span class="badge badge-failed">INCONSISTENTE</span>';
    if (status === 'NÃO VERIFICADO') return '<span class="badge badge-neutral">NÃO VERIFICADO</span>';
    return `<span class="badge badge-info">${esc(status || 'SEM STATUS')}</span>`;
  }
  function searchBadge(status) {
    const labels = {completed: 'CONCLUÍDA', running: 'EM EXECUÇÃO', queued: 'NA FILA', failed: 'FALHOU', cancelled: 'CANCELADA', cancelling: 'CANCELANDO'};
    const classes = {completed: 'badge-verified', running: 'badge-purple', queued: 'badge-info', failed: 'badge-failed', cancelled: 'badge-neutral', cancelling: 'badge-partial'};
    return `<span class="badge ${classes[status] || 'badge-neutral'}">${labels[status] || esc(status)}</span>`;
  }
  function toast(message, type = 'success') {
    const node = document.createElement('div');
    node.className = `toast ${type}`;
    node.textContent = message;
    $('#toast-root').appendChild(node);
    setTimeout(() => { node.classList.add('toast-out'); setTimeout(() => node.remove(), 300); }, 3800);
  }
  async function api(path, options = {}) {
    const headers = {'Content-Type': 'application/json', ...(options.headers || {})};
    if (state.csrf && !['GET', 'HEAD'].includes(options.method || 'GET')) headers['X-CSRF-Token'] = state.csrf;
    const response = await fetch(API_BASE + path, {...options, headers, credentials: 'include'});
    const text = await response.text();
    let data = {};
    try { data = text ? JSON.parse(text) : {}; } catch { data = {error: text.slice(0, 200)}; }
    if (response.status === 401 && path !== '/api/auth/login') {
      state.user = null; state.csrf = null; showLogin();
      throw new Error('Sessão expirada. Entre novamente.');
    }
    if (!response.ok) throw new Error(data.error || `Erro HTTP ${response.status}`);
    return data;
  }
  function jsonOptions(method, body) { return {method, body: JSON.stringify(body || {})}; }
  function debounce(fn, wait = 350) { let timer; return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), wait); }; }

  function hideIntro() {
    clearTimeout(state.introTimer);
    const intro = $('#intro');
    if (!intro || intro.classList.contains('intro-out')) return;
    intro.classList.add('intro-out');
    setTimeout(() => intro.classList.add('hidden'), 750);
  }
  function showLogin() {
    $('#app').classList.add('hidden');
    $('#login-view').classList.remove('hidden');
    document.body.classList.remove('modal-open');
  }
  async function showApp() {
    $('#login-view').classList.add('hidden');
    $('#app').classList.remove('hidden');
    setLoading();
    $('#owner-email').textContent = state.user.email;
    $('#owner-initial').textContent = state.user.email.slice(0, 1).toUpperCase();
    await loadCore();
    navigate(state.page || 'overview');
  }
  async function loadCore() {
    const [integrations, settings, dashboard, searches, leads] = await Promise.all([
      api('/api/integrations'), api('/api/settings'), api('/api/dashboard'), api('/api/research'), api('/api/leads?limit=1000'),
    ]);
    state.integrations = integrations;
    state.settings = settings;
    state.dashboard = dashboard;
    state.searches = searches.searches;
    state.allLeads = leads.leads;
    $('#sidebar-provider').textContent = integrations.active_provider === 'google_places' ? 'Google Places + fontes públicas' : 'OpenStreetMap · APIs opcionais pendentes';
    $('#nav-results-count').textContent = dashboard.total_companies;
    applyMotionPreference();
  }
  function applyMotionPreference() {
    document.body.classList.toggle('reduce-motion', Boolean(state.settings.reduced_motion));
    if (state.settings.reduced_motion) hideIntro();
  }
  async function refreshDashboard() {
    state.dashboard = await api('/api/dashboard');
    state.searches = (await api('/api/research')).searches;
    state.allLeads = (await api('/api/leads?limit=1000')).leads;
    $('#nav-results-count').textContent = state.dashboard.total_companies;
  }
  function setLoading() { $('#page-content').innerHTML = '<div class="panel empty-state"><div class="empty-icon scanning"></div><h3>Carregando dados reais</h3><p>Consultando o banco e as integrações configuradas.</p></div>'; }

  async function navigate(page) {
    if (!pageMeta[page]) page = 'overview';
    state.page = page;
    const token = ++state.navToken;
    $$('.nav-item[data-page]').forEach(button => button.classList.toggle('active', button.dataset.page === page));
    $('#topbar-title').textContent = pageMeta[page][0];
    $('#breadcrumb').textContent = pageMeta[page][1];
    $('#app').classList.remove('mobile-open');
    setLoading();
    try {
      if (page === 'overview') await refreshDashboard();
      if (['results', 'saved', 'clients', 'prompts'].includes(page)) await loadLeads(page);
      if (page === 'history') state.searches = (await api('/api/research')).searches;
      if (page === 'settings') {
        state.integrations = await api('/api/integrations');
        state.settings = await api('/api/settings');
      }
      if (token !== state.navToken) return;
      renderCurrentPage();
    } catch (error) {
      $('#page-content').innerHTML = `<div class="panel empty-state"><div class="empty-icon">!</div><h3>Não foi possível carregar</h3><p>${esc(error.message)}</p><button class="btn btn-primary" data-action="retry-load">Tentar novamente</button></div>`;
    }
  }
  function renderCurrentPage() {
    const content = $('#page-content');
    content.style.animation = 'none';
    void content.offsetHeight;
    content.style.animation = '';
    const renderers = {overview: renderOverview, 'new-research': renderNewResearch, results: () => renderLeadCollection('results'), saved: () => renderLeadCollection('saved'), clients: renderClients, history: renderHistory, prompts: renderPrompts, settings: renderSettings};
    content.innerHTML = renderers[state.page]();
    content.focus({preventScroll: true});
  }
  async function loadLeads(page) {
    const filters = {...state.filters};
    if (page === 'saved') filters.saved = true;
    if (page === 'clients') filters.potential_client = true;
    const query = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => { if (value !== '' && value !== null && value !== undefined && value !== false) query.set(key, value); });
    query.set('limit', '1000');
    const response = await api('/api/leads?' + query.toString());
    state.leads = response.leads;
  }

  function renderOverview() {
    const d = state.dashboard;
    const metrics = [
      ['Empresas encontradas', d.total_companies, 'Banco persistente', '⌁'],
      ['Leads verificados', d.verified, `${d.partial} parciais · ${d.not_qualified} não qualificados`, '✓'],
      ['Oportunidades', d.opportunities, 'Com análise individual', '↗'],
      ['Projetos preparados', d.projects_prepared, `${d.saved_leads} leads salvos`, '◇'],
    ];
    return `<section class="welcome-panel"><span class="eyebrow">CENTRAL DE INTELIGÊNCIA COMERCIAL</span><h1>Sua próxima oportunidade está em <span>uma nova órbita.</span></h1><p>Pesquise empresas, valide canais públicos e transforme dados reais em projetos personalizados para a Arena AI.</p><div class="welcome-actions"><button class="btn btn-primary" data-page="new-research">Iniciar prospecção <b>→</b></button><button class="btn btn-ghost" data-page="results">Explorar resultados</button></div></section>
      <section class="metrics-grid">${metrics.map(([label, value, note, symbol]) => `<article class="metric-card"><div class="metric-top"><span>${label}</span><span class="metric-icon">${symbol}</span></div><div class="metric-value">${fmtNumber(value)}</div><div class="metric-note">${note}</div></article>`).join('')}</section>
      <section class="dashboard-grid"><div class="panel"><div class="panel-head"><div><h3>Últimas pesquisas</h3><p>Execuções e resultados preservados</p></div><button class="btn btn-ghost btn-small" data-page="history">Ver histórico</button></div><div class="table-wrap">${renderSearchesTable(d.recent_searches, true)}</div></div>
      <div class="panel"><div class="panel-head"><div><h3>Atividades recentes</h3><p>Alterações reais no sistema</p></div></div><div class="activity-list">${renderActivities(d.recent_activities)}</div></div></section>
      <section class="panel" style="margin-top:18px"><div class="panel-head"><div><h3>Atalhos de trabalho</h3><p>Fluxos principais, sem etapas desnecessárias</p></div></div><div class="panel-body quick-grid"><button class="quick-card" data-page="new-research"><span>⌖</span><b>Pesquisar nova região</b><small>Execute uma prospecção real por nicho e localização.</small></button><button class="quick-card" data-page="saved"><span>◇</span><b>Revisar leads salvos</b><small>Priorize empresas e organize o funil comercial.</small></button><button class="quick-card" data-page="prompts"><span>{ }</span><b>Preparar Arena AI</b><small>Copie ou baixe briefings JSON individuais.</small></button></div></section>`;
  }
  function renderActivities(items) {
    if (!items?.length) return '<div class="empty-state"><p>Nenhuma atividade registrada ainda.</p></div>';
    return items.map(item => `<div class="activity-item"><span class="activity-dot"></span><div><b>${esc(item.name || 'Sistema')}</b><p>${esc(item.note)}</p></div><time>${fmtDate(item.created_at, true)}</time></div>`).join('');
  }
  function renderSearchesTable(searches, compact = false) {
    if (!searches?.length) return '<div class="empty-state"><p>Nenhuma pesquisa realizada ainda.</p><button class="btn btn-primary btn-small" data-page="new-research">Começar agora</button></div>';
    return `<table class="data-table"><thead><tr><th>Pesquisa</th><th>Status</th><th>Empresas</th>${compact ? '' : '<th>Verificadas</th><th>Provedor</th>'}<th>Ação</th></tr></thead><tbody>${searches.map(search => `<tr><td><span class="cell-title">${esc(search.niche)}</span><span class="cell-sub">${esc([search.neighborhood, search.city, search.region].filter(Boolean).join(' · ') || 'Região não informada')} · ${fmtDate(search.created_at)}</span></td><td>${searchBadge(search.status)}${['running', 'queued', 'cancelling'].includes(search.status) ? `<div class="progress" style="margin-top:7px;width:100px"><span style="width:${search.progress}%"></span></div>` : ''}</td><td>${search.found_count}/${search.desired_count}</td>${compact ? '' : `<td>${search.verified_count}</td><td><span class="cell-sub">${esc(search.provider)}</span></td>`}<td><button class="btn btn-ghost btn-small" data-action="open-search" data-id="${search.id}">Abrir</button>${['running', 'queued'].includes(search.status) ? `<button class="icon-action" title="Cancelar" data-action="cancel-research" data-id="${search.id}">×</button>` : ''}</td></tr>`).join('')}</tbody></table>`;
  }

  function integrationCards() {
    if (!state.integrations) return '';
    return Object.values(state.integrations).filter(x => x && typeof x === 'object' && x.label).map(item => `<article class="integration-card"><div class="integration-top"><b>${esc(item.label)}</b><span class="badge ${item.configured ? 'badge-verified' : 'badge-neutral'}">${item.configured ? 'DISPONÍVEL' : 'NÃO CONFIGURADA'}</span></div><p>${esc(item.note)}</p></article>`).join('');
  }
  function renderNewResearch() {
    const s = state.settings;
    const current = state.currentResearchData;
    return `<div class="page-heading"><div><span class="eyebrow">MOTOR DE PROSPECÇÃO</span><h1>Encontrar novas oportunidades</h1><p>Descoberta real, validação individual e classificação por evidência.</p></div></div>
      <div class="research-layout"><section class="panel"><div class="panel-head"><div><h3>Parâmetros da pesquisa</h3><p>Preencha somente o necessário para começar</p></div></div><div class="panel-body"><form id="research-form"><div class="form-grid">
        <div class="field"><label>Região<span>opcional</span><input name="region" placeholder="Ex.: Zona Norte" maxlength="120"></label></div>
        <div class="field"><label>Bairro<span>opcional</span><input name="neighborhood" placeholder="Ex.: Jardim Primavera" maxlength="120"></label></div>
        <div class="field"><label>Cidade<input name="city" value="São Paulo" maxlength="120" required></label></div>
        <div class="field"><label>Nicho ou segmento<input name="niche" placeholder="Ex.: Hamburguerias" maxlength="120" required></label></div>
        <div class="field full"><label>Quantidade e faixa de seguidores</label><div class="input-group"><label>Empresas<input name="desired_count" type="number" min="1" max="50" value="${s.default_desired_count || 20}" required></label><label>Mínimo<input name="min_followers" type="number" min="0" value="${s.default_min_followers ?? 900}"></label><label>Máximo<input name="max_followers" type="number" min="0" value="${s.default_max_followers ?? 10000}"></label></div><small>Seguidores ausentes não excluem automaticamente uma empresa.</small></div>
        <div class="field full"><label>Critérios configuráveis</label><div class="check-grid"><label class="check-item"><input type="checkbox" name="strict_followers"><span><b>Faixa de seguidores obrigatória</b><small>Aplica-se somente quando o número for conhecido.</small></span></label><label class="check-item"><input type="checkbox" name="require_recent_social"><span><b>Exigir atividade social recente</b><small>Dados ausentes reduzem a confiança, não viram inatividade.</small></span></label><label class="check-item"><input type="checkbox" name="only_without_site"><span><b>Somente sem site funcionando</b><small>Sites confirmados e ativos ficam fora da qualificação.</small></span></label><label class="check-item"><input type="checkbox" name="exclude_closed" checked><span><b>Evitar negócios fechados</b><small>Usa o status operacional quando a fonte o informa.</small></span></label></div></div>
        <div class="field full"><label>Critérios adicionais<span>opcional</span><textarea name="notes" rows="3" maxlength="500" placeholder="Ex.: priorizar pequenos negócios com contato público e oportunidade de cardápio digital"></textarea></label></div>
      </div><div class="research-submit"><button class="btn btn-primary" type="submit">INICIAR PROSPECÇÃO <b>↗</b></button><p>A busca usa fontes reais. Se uma integração estiver indisponível, o erro será mostrado e nenhum lead fictício será criado.</p></div></form></div></section>
      <aside class="panel"><div class="panel-head"><div><h3>Integrações</h3><p>Estado real do backend</p></div></div><div class="panel-body integration-list">${integrationCards()}<div class="security-note">Chaves são lidas apenas de variáveis de ambiente no backend. Nenhuma credencial aparece nesta interface.</div></div></aside></div>
      <div id="research-progress">${current ? renderResearchConsole(current) : ''}</div>`;
  }
  function renderResearchConsole(search) {
    const active = ['running', 'queued', 'cancelling'].includes(search.status);
    return `<section class="research-console" data-search-console="${search.id}"><div class="console-head"><h3>${active ? '<span class="scanning">Pesquisa em andamento</span>' : 'Execução da pesquisa'}</h3><div>${searchBadge(search.status)} <button class="btn btn-ghost btn-small" data-action="open-search" data-id="${search.id}">Ver resultados</button>${active ? `<button class="btn btn-danger btn-small" data-action="cancel-research" data-id="${search.id}">Cancelar</button>` : ''}</div></div><div class="console-body"><div class="progress"><span style="width:${search.progress}%"></span></div><div class="progress-text"><span>${esc(search.current_step || 'Aguardando')}</span><b>${search.progress}%</b></div><div class="console-events">${(search.events || []).map(event => `<div class="console-event ${event.level}"><time>${new Date(event.created_at).toLocaleTimeString('pt-BR', {hour: '2-digit', minute: '2-digit', second: '2-digit'})}</time><span>${esc(event.message)}</span></div>`).join('')}</div></div></section>`;
  }
  async function startResearch(form) {
    const data = new FormData(form);
    const body = {
      region: data.get('region'), neighborhood: data.get('neighborhood'), city: data.get('city'), niche: data.get('niche'),
      desired_count: Number(data.get('desired_count')), min_followers: data.get('min_followers') === '' ? null : Number(data.get('min_followers')),
      max_followers: data.get('max_followers') === '' ? null : Number(data.get('max_followers')),
      criteria: {strict_followers: data.get('strict_followers') === 'on', require_recent_social: data.get('require_recent_social') === 'on', only_without_site: data.get('only_without_site') === 'on', exclude_closed: data.get('exclude_closed') === 'on', notes: data.get('notes')},
    };
    const button = $('button[type="submit"]', form);
    button.disabled = true;
    try {
      const search = await api('/api/research', jsonOptions('POST', body));
      state.currentResearch = search.id;
      state.currentResearchData = search;
      $('#research-progress').innerHTML = renderResearchConsole(search);
      toast('Pesquisa iniciada com fontes reais.');
      pollResearch(search.id);
    } catch (error) { toast(error.message, 'error'); }
    finally { button.disabled = false; }
  }
  function pollResearch(searchId) {
    clearInterval(state.pollTimer);
    const update = async () => {
      try {
        const search = await api('/api/research/' + searchId);
        state.currentResearchData = search;
        if (state.page === 'new-research') $('#research-progress').innerHTML = renderResearchConsole(search);
        if (!['running', 'queued', 'cancelling'].includes(search.status)) {
          clearInterval(state.pollTimer);
          state.pollTimer = null;
          await refreshDashboard();
          if (search.status === 'completed') toast(`Pesquisa concluída: ${search.found_count} empresas processadas.`);
          else if (search.status === 'failed') toast('A pesquisa falhou. Abra o histórico para ver o erro.', 'error');
          else toast('Pesquisa cancelada; resultados processados foram preservados.', 'warning');
        }
      } catch (error) { clearInterval(state.pollTimer); toast(error.message, 'error'); }
    };
    update();
    state.pollTimer = setInterval(update, 1600);
  }

  function renderLeadCollection(mode) {
    const titles = {results: ['Resultados da prospecção', 'Analise empresas, confiança e oportunidades comerciais.'], saved: ['Leads salvos', 'Sua seleção prioritária para análise e abordagem.']};
    const [title, subtitle] = titles[mode];
    return `<div class="page-heading"><div><span class="eyebrow">BASE DE EMPRESAS</span><h1>${title}</h1><p>${subtitle}</p></div><div class="page-heading-actions"><button class="btn btn-primary" data-page="new-research">＋ Nova pesquisa</button></div></div>${renderFilters(mode)}${state.leads.length ? `<div class="lead-grid">${state.leads.map(renderLeadCard).join('')}</div>` : `<div class="panel empty-state"><div class="empty-icon">⌖</div><h3>Nenhum lead nesta visão</h3><p>Ajuste os filtros ou execute uma nova pesquisa com fontes reais.</p><button class="btn btn-ghost" data-action="clear-filters">Limpar filtros</button></div>`}`;
  }
  function renderFilters(mode) {
    const f = state.filters;
    const segments = [...new Set(state.allLeads.map(x => x.segment).filter(Boolean))].sort();
    const regions = [...new Set(state.allLeads.map(x => x.region).filter(Boolean))].sort();
    return `<div class="filter-bar"><input class="input search-input" id="filter-q" value="${esc(f.q || '')}" placeholder="Buscar por nome, endereço ou bairro"><select class="select" id="filter-search"><option value="">Todas as pesquisas</option>${state.searches.map(s => `<option value="${s.id}" ${f.search_id === s.id ? 'selected' : ''}>${esc(s.niche)} · ${fmtDate(s.created_at)}</option>`).join('')}</select><select class="select" id="filter-status"><option value="">Todos os status</option>${['VERIFICADO', 'PARCIALMENTE VERIFICADO', 'NÃO QUALIFICADO'].map(x => `<option ${f.qualification_status === x ? 'selected' : ''}>${x}</option>`).join('')}</select><select class="select" id="filter-segment"><option value="">Todos os nichos</option>${segments.map(x => `<option ${f.segment === x ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select><select class="select" id="filter-region"><option value="">Todas as regiões</option>${regions.map(x => `<option ${f.region === x ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select><button class="btn btn-ghost btn-small" data-action="clear-filters">Limpar</button><span class="filter-count">${state.leads.length} resultados</span></div>`;
  }
  function linkPill(label, url, status) {
    const cls = status === 'VERIFICADO' ? 'verified' : status === 'INCONSISTENTE' ? 'failed' : 'issue';
    const content = `<span class="mini-status"></span>${esc(label)}`;
    const safe = safeUrl(url);
    return safe ? `<a class="link-pill ${cls}" href="${esc(safe)}" target="_blank" rel="noopener noreferrer" title="${esc(status || 'Sem status')}">${content}</a>` : `<span class="link-pill disabled" title="Não localizado">${content}</span>`;
  }
  function renderLeadCard(lead) {
    const initial = esc((lead.name || 'M').trim().slice(0, 1).toUpperCase());
    const image = safeUrl(lead.image_url);
    return `<article class="lead-card"><div class="lead-head"><div class="lead-avatar">${image ? `<img src="${esc(image)}" alt="" loading="lazy">` : initial}</div><div class="lead-title"><h3>${esc(lead.name)}</h3><p>${esc(lead.segment || 'Segmento não informado')}</p><div class="lead-badges">${statusBadge(lead.qualification_status)}${lead.saved ? '<span class="badge badge-purple">SALVO</span>' : ''}</div></div><div class="lead-confidence"><strong>${lead.confidence ?? 0}</strong><span>CONFIANÇA</span></div></div>
      <div class="lead-location"><span>⌖</span><span>${esc(lead.neighborhood || 'Bairro não informado')} · ${esc(lead.city || 'Cidade não informada')}</span></div>
      <div class="lead-metrics"><div class="lead-metric"><span>Seguidores</span><b>${fmtNumber(lead.followers)}</b></div><div class="lead-metric"><span>Última publicação</span><b>${esc(lead.last_post_date || '—')}</b></div><div class="lead-metric"><span>Google</span><b>${lead.rating ?? '—'} ${lead.review_count ? `(${lead.review_count})` : ''}</b></div></div>
      <div class="lead-links">${linkPill('Instagram', lead.instagram_url, lead.instagram_status)}${linkPill('WhatsApp', lead.whatsapp_url, lead.whatsapp_status)}${linkPill('Site', lead.site_url, lead.site_status)}${linkPill('Maps', lead.maps_url, lead.maps_status)}</div>
      <div class="lead-analysis">${esc(lead.commercial_analysis || 'Dados insuficientes para análise comercial; abra os detalhes para revisar as pendências.')}</div>
      <div class="opportunity-strip"><span>Oportunidade</span><b>${esc(lead.opportunity_level || 'A avaliar')}</b></div>
      <div class="lead-footer"><button class="icon-action ${lead.saved ? 'active' : ''}" title="${lead.saved ? 'Remover dos salvos' : 'Salvar lead'}" data-action="save-lead" data-id="${lead.id}">◇</button><button class="icon-action ${lead.potential_client ? 'active' : ''}" title="Marcar como cliente potencial" data-action="potential-lead" data-id="${lead.id}">↗</button><button class="icon-action" title="Copiar mensagem" data-action="copy-message" data-id="${lead.id}" ${lead.approach_message ? '' : 'disabled'}>⧉</button><button class="btn btn-ghost" data-action="briefing" data-id="${lead.id}">{ }</button><button class="btn btn-primary" data-action="details" data-id="${lead.id}">Detalhes</button></div></article>`;
  }

  function renderClients() {
    const groups = [
      ['Novos e analisados', ['Novo lead', 'Lead analisado']], ['Em contato', ['Contato realizado', 'Aguardando resposta']],
      ['Negociação', ['Interessado', 'Reunião ou negociação']], ['Fechamento', ['Cliente fechado', 'Não interessado']],
    ];
    return `<div class="page-heading"><div><span class="eyebrow">CRM INTERNO</span><h1>Clientes qualificados</h1><p>Empresas marcadas como potenciais, com etapas e histórico comercial.</p></div><div class="page-heading-actions"><button class="btn btn-ghost" data-page="results">Marcar novos potenciais</button></div></div>${state.leads.length ? `<div class="crm-grid">${groups.map(([title, list]) => { const leads = state.leads.filter(x => list.includes(x.commercial_stage)); return `<section class="crm-column"><div class="crm-column-head"><h3>${title}</h3><span>${leads.length}</span></div><div class="crm-column-body">${leads.length ? leads.map(lead => `<article class="crm-card" data-action="details" data-id="${lead.id}"><b>${esc(lead.name)}</b><p>${esc(lead.commercial_stage)} · ${esc(lead.segment)}</p></article>`).join('') : '<p class="text-muted text-small">Nenhum lead nesta etapa.</p>'}</div></section>`; }).join('')}</div>` : `<div class="panel empty-state"><div class="empty-icon">↗</div><h3>Nenhum cliente potencial marcado</h3><p>Use o botão de cliente potencial nos cards para montar seu funil. Nenhuma empresa foi marcada automaticamente como contatada.</p><button class="btn btn-primary" data-page="results">Ver resultados</button></div>`}`;
  }
  function renderHistory() {
    return `<div class="page-heading"><div><span class="eyebrow">PESQUISAS PERSISTENTES</span><h1>Histórico de pesquisas</h1><p>Abra resultados anteriores sem executar a coleta novamente.</p></div><div class="page-heading-actions"><button class="btn btn-primary" data-page="new-research">＋ Nova pesquisa</button></div></div><section class="panel"><div class="panel-head"><div><h3>${state.searches.length} execuções armazenadas</h3><p>Inclui a prospecção histórica importada e novas pesquisas</p></div></div><div class="table-wrap">${renderSearchesTable(state.searches)}</div></section>`;
  }
  function renderPrompts() {
    const query = (state.filters.q || '').toLowerCase();
    const leads = state.leads.filter(x => !query || x.name.toLowerCase().includes(query));
    return `<div class="page-heading"><div><span class="eyebrow">ARENA AI</span><h1>Superprompts JSON</h1><p>Briefings individuais válidos, editáveis e prontos para copiar ou baixar.</p></div></div><div class="filter-bar"><input class="input search-input" id="filter-q" value="${esc(state.filters.q || '')}" placeholder="Buscar empresa"><span class="filter-count">${leads.length} empresas</span></div><div class="prompt-list">${leads.map(lead => `<article class="prompt-item"><div><h3>${esc(lead.name)}</h3><p>${esc(lead.segment)} · ${esc(lead.neighborhood || 'Região não informada')}</p></div><span class="badge ${lead.briefing ? 'badge-verified' : 'badge-neutral'}">${lead.briefing ? 'JSON PRONTO' : 'GERAR SOB DEMANDA'}</span><div><button class="btn btn-ghost btn-small" data-action="details" data-id="${lead.id}">Editar dados</button> <button class="btn btn-primary btn-small" data-action="briefing" data-id="${lead.id}">${lead.briefing ? 'Abrir JSON' : 'Gerar JSON'}</button></div></article>`).join('')}</div>`;
  }
  function renderSettings() {
    const s = state.settings;
    return `<div class="page-heading"><div><span class="eyebrow">SISTEMA E INTEGRAÇÕES</span><h1>Configurações</h1><p>Preferências não sensíveis, segurança e dependências reais.</p></div></div><div class="settings-grid"><section class="panel"><div class="panel-head"><div><h3>Integrações de pesquisa</h3><p>Chaves somente no backend</p></div></div><div class="panel-body integration-list">${integrationCards()}</div></section>
      <section class="panel"><div class="panel-head"><div><h3>Preferências de prospecção</h3><p>Valores iniciais, editáveis a qualquer momento</p></div></div><div class="panel-body settings-form"><form id="settings-form"><div class="form-grid"><div class="field"><label>Quantidade padrão<input name="default_desired_count" type="number" min="1" max="50" value="${s.default_desired_count || 20}"></label></div><div class="field"><label>Resultados por página<input name="results_per_page" type="number" min="6" max="100" value="${s.results_per_page || 24}"></label></div><div class="field"><label>Seguidores mínimos<input name="default_min_followers" type="number" min="0" value="${s.default_min_followers ?? 900}"></label></div><div class="field"><label>Seguidores máximos<input name="default_max_followers" type="number" min="0" value="${s.default_max_followers ?? 10000}"></label></div><div class="field full"><label class="check-item"><input name="reduced_motion" type="checkbox" ${s.reduced_motion ? 'checked' : ''}><span><b>Reduzir animações</b><small>Também respeitamos a preferência do sistema operacional.</small></span></label></div></div><button class="btn btn-primary" type="submit">Salvar preferências</button></form></div></section>
      <section class="panel"><div class="panel-head"><div><h3>Segurança do proprietário</h3><p>Alterar senha invalida as sessões atuais</p></div></div><div class="panel-body settings-form"><form id="password-form"><div class="field"><label>Senha atual<input name="current_password" type="password" autocomplete="current-password" required></label></div><div class="field"><label>Nova senha<input name="new_password" type="password" minlength="12" autocomplete="new-password" required><small>Mínimo de 12 caracteres.</small></label></div><button class="btn btn-ghost" type="submit">Alterar senha</button></form></div></section>
      <section class="panel"><div class="panel-head"><div><h3>Publicação</h3><p>Netlify + backend externo</p></div></div><div class="panel-body"><p class="text-muted text-small">O build do frontend grava somente a URL pública da API. Segredos permanecem no servidor.</p><div class="code-note">API_BASE_URL=https://sua-api.exemplo.com\nALLOWED_ORIGINS=https://seu-site.netlify.app\nCOOKIE_SECURE=1\nCOOKIE_SAMESITE=None\nGOOGLE_PLACES_API_KEY=...\nGOOGLE_CSE_API_KEY=...\nGOOGLE_CSE_CX=...\nMOON_AI_API_KEY=...\nMOON_AI_MODEL=...</div><p class="text-small"><a href="https://docs.netlify.com" target="_blank" rel="noopener noreferrer">Documentação da Netlify ↗</a></p></div></section></div>`;
  }

  function openModal(content, small = false) {
    document.body.classList.add('modal-open');
    $('#modal-root').innerHTML = `<div class="modal-backdrop"><section class="modal ${small ? 'modal-small' : ''}" role="dialog" aria-modal="true">${content}</section></div>`;
    $('.modal .modal-close')?.focus();
  }
  function closeModal() { $('#modal-root').innerHTML = ''; document.body.classList.remove('modal-open'); state.modalLead = null; }
  function modalHeader(title, subtitle) { return `<div class="modal-head"><div><h2>${esc(title)}</h2><p>${esc(subtitle || '')}</p></div><button class="icon-btn modal-close" data-action="close-modal" aria-label="Fechar">×</button></div>`; }

  async function openLead(leadId) {
    openModal(`${modalHeader('Carregando lead', 'Consultando dados armazenados')}<div class="modal-body"><div class="empty-state scanning">Carregando</div></div>`);
    try {
      const lead = await api('/api/leads/' + leadId);
      state.modalLead = lead;
      renderLeadModal(lead);
    } catch (error) { closeModal(); toast(error.message, 'error'); }
  }
  function detailLink(label, url, status, note) {
    const safe = safeUrl(url);
    return `<div class="detail-link"><b>${esc(label)}</b>${safe ? `<a href="${esc(safe)}" target="_blank" rel="noopener noreferrer">${esc(safe)}</a>` : '<span class="text-muted">Não localizado</span>'}<div>${statusBadge(status)}${note ? `<span class="cell-sub">${esc(note)}</span>` : ''}</div></div>`;
  }
  function reviewSection(lead) {
    const reviews = lead.reviews || [];
    if (!reviews.length) return '<p class="text-muted">Nenhuma avaliação pública foi coletada para esta empresa. A nota agregada, quando existe, permanece nos dados acima.</p>';
    return `<details class="detail-disclosure" open><summary>Avaliações do Google · ${reviews.length} relatos públicos</summary><div><p class="text-muted text-small">Amostra de cartões públicos, não exportação completa. São relatos dos autores, não fatos verificados ou materiais autorizados para publicidade.</p><div class="review-list">${reviews.map(review => `<article class="review-card"><div class="review-card-head"><strong>${esc(review.author || 'Autor não exposto')}</strong><span>${esc(review.rating_label || 'Nota não exposta')} · ${esc(review.date_display || 'Data não exposta')}</span></div><p>${esc(review.text || 'Sem texto público.')}</p>${safeUrl(review.source_url) ? `<a class="text-small" href="${esc(review.source_url)}" target="_blank" rel="noopener noreferrer">Fonte no Google Maps ↗</a>` : ''}</article>`).join('')}</div></div></details>`;
  }
  function renderLeadModal(lead) {
    const links = [
      ['Instagram', lead.instagram_url, lead.instagram_status], ['WhatsApp', lead.whatsapp_url, lead.whatsapp_status],
      ['Site atual', lead.site_url, lead.site_status], ['Google Maps', lead.maps_url, lead.maps_status],
    ];
    const other = lead.other_links || [];
    const sources = lead.sources || [];
    const pendings = lead.unconfirmed || [];
    const events = lead.events || [];
    const content = `${modalHeader(lead.name, `${lead.segment || 'Segmento não informado'} · ${lead.neighborhood || 'Bairro não informado'}`)}<div class="modal-body">
      <div class="detail-actions">${statusBadge(lead.qualification_status)}<span class="badge badge-purple">CONFIANÇA ${lead.confidence ?? 0}</span><button class="btn btn-ghost btn-small" data-action="save-lead" data-id="${lead.id}">${lead.saved ? 'Remover dos salvos' : 'Salvar lead'}</button><button class="btn btn-ghost btn-small" data-action="potential-lead" data-id="${lead.id}">${lead.potential_client ? 'Remover cliente potencial' : 'Marcar cliente potencial'}</button><button class="btn btn-primary btn-small" data-action="briefing" data-id="${lead.id}">Abrir superprompt JSON</button><button class="btn btn-ghost btn-small" data-action="copy-message" data-id="${lead.id}">Copiar abordagem</button><button class="btn btn-ghost btn-small" data-action="edit-lead" data-id="${lead.id}">Editar dados</button></div>
      <div class="detail-actions"><label class="text-small">Etapa comercial <select class="select stage-select" data-action="change-stage" data-id="${lead.id}">${stages.map(x => `<option ${x === lead.commercial_stage ? 'selected' : ''}>${x}</option>`).join('')}</select></label><label class="text-small">Projeto <select class="select stage-select" data-action="change-project" data-id="${lead.id}">${projectStatuses.map(x => `<option ${x === lead.project_status ? 'selected' : ''}>${x}</option>`).join('')}</select></label></div>
      <div class="detail-grid"><section class="detail-section"><h3>Informações da empresa</h3>${[['Endereço', lead.address], ['Bairro', lead.neighborhood], ['Cidade / região', [lead.city, lead.region].filter(Boolean).join(' · ')], ['Seguidores', fmtNumber(lead.followers)], ['Última publicação', lead.last_post_date], ['Nota Google', lead.rating], ['Avaliações', lead.review_count], ['Horários', lead.hours], ['Serviços confirmados', (lead.services || []).join(', ')], ['Formas de pedido', (lead.order_methods || []).join(', ')]].map(([k, v]) => `<div class="detail-kv"><span>${k}</span><b>${esc(v || '—')}</b></div>`).join('')}</section>
      <section class="detail-section"><h3>Análise comercial</h3><p>${esc(lead.commercial_analysis || 'Sem análise suficiente; revise as pendências.')}</p><h3>Oportunidade</h3><p>${esc(lead.opportunity_level || 'A avaliar')}</p><h3>Mensagem sugerida · não enviada</h3><p>${esc(lead.approach_message || 'Dados insuficientes para uma abordagem responsável.')}</p></section>
      <section class="detail-section full"><h3>Links verificados e fontes</h3><div class="detail-links">${links.map(([label, url, status]) => detailLink(label, url, status)).join('')}${other.map(link => detailLink(link.plataforma || 'Outra plataforma', link.url, link.status, link.observacao || link.fonte)).join('')}</div></section>
      <section class="detail-section full"><h3>Evidências públicas</h3>${reviewSection(lead)}<details class="detail-disclosure"><summary>Fontes e verificações · ${sources.length}</summary><div><div class="source-list">${sources.length ? sources.map(source => `<div class="source-item"><b>${esc(source.tipo || 'Fonte')}</b><span>${esc(source.resultado || source.result || '')}</span>${safeUrl(source.url) ? `<a href="${esc(source.url)}" target="_blank" rel="noopener noreferrer">${esc(source.url)}</a>` : ''}<small>${esc(source.data || '')}</small></div>`).join('') : '<p class="text-muted">Nenhuma fonte adicional registrada.</p>'}</div></div></details></section>
      <section class="detail-section"><h3>Pendências e inconsistências</h3>${pendings.length ? `<ul>${pendings.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : '<p class="text-muted">Nenhuma pendência textual registrada.</p>'}${(lead.problem_links || []).map(x => `<p>${statusBadge(x.status)} ${esc(x.plataforma)}</p>`).join('')}<h3>Observações</h3><div class="notes-box">${esc(lead.notes || 'Nenhuma observação comercial.')}</div><form class="note-form" id="note-form" data-id="${lead.id}"><input class="input" name="note" placeholder="Adicionar observação" required><button class="btn btn-primary btn-small" type="submit">Adicionar</button></form></section>
      <section class="detail-section"><h3>Histórico do lead</h3><div class="event-list">${events.length ? events.map(event => `<div class="event-item"><time>${fmtDate(event.created_at, true)} · ${esc(event.event_type)}</time>${esc(event.note)}</div>`).join('') : '<p class="text-muted">Sem eventos.</p>'}</div><div class="danger-zone" style="margin-top:18px"><h3>Remover empresa</h3><p>Exclui o lead e suas associações do banco. Esta ação não pode ser desfeita.</p><button class="btn btn-danger btn-small" data-action="delete-lead" data-id="${lead.id}">Excluir lead</button></div></section>
      </div></div><div class="modal-footer"><button class="btn btn-ghost" data-action="close-modal">Fechar</button></div>`;
    openModal(content);
  }

  function openEditLead(lead) {
    const fields = [
      ['name', 'Nome', lead.name], ['segment', 'Segmento', lead.segment], ['neighborhood', 'Bairro', lead.neighborhood], ['city', 'Cidade', lead.city],
      ['region', 'Região', lead.region], ['address', 'Endereço', lead.address], ['instagram_url', 'Instagram', lead.instagram_url],
      ['whatsapp_number', 'Número WhatsApp', lead.whatsapp_number], ['whatsapp_url', 'URL WhatsApp', lead.whatsapp_url],
      ['site_url', 'Site atual', lead.site_url], ['maps_url', 'Google Maps', lead.maps_url], ['followers', 'Seguidores', lead.followers],
      ['last_post_date', 'Última publicação', lead.last_post_date], ['hours', 'Horários', lead.hours],
    ];
    openModal(`${modalHeader('Editar ' + lead.name, 'Alterações de URL reiniciam o status de verificação')}<div class="modal-body"><form id="edit-lead-form" data-id="${lead.id}"><div class="edit-grid">${fields.map(([name, label, value]) => `<div class="field"><label>${label}<input name="${name}" value="${esc(value || '')}" ${name === 'name' ? 'required' : ''}></label></div>`).join('')}
      <div class="field full"><label>Análise comercial<textarea name="commercial_analysis">${esc(lead.commercial_analysis || '')}</textarea></label></div><div class="field full"><label>Mensagem de abordagem<textarea name="approach_message">${esc(lead.approach_message || '')}</textarea></label></div><div class="field full"><label>Serviços confirmados<textarea name="services" placeholder="Um por linha">${esc((lead.services || []).join('\n'))}</textarea></label></div><div class="field full"><label>Produtos confirmados<textarea name="products" placeholder="Um por linha">${esc((lead.products || []).join('\n'))}</textarea></label></div><div class="field full"><label>Formas de pedido<textarea name="order_methods" placeholder="Uma por linha">${esc((lead.order_methods || []).join('\n'))}</textarea></label></div><div class="field full"><label>Observações<textarea name="notes">${esc(lead.notes || '')}</textarea></label></div></div><div class="modal-footer" style="margin:20px -22px -22px"><button class="btn btn-ghost" type="button" data-action="details" data-id="${lead.id}">Cancelar</button><button class="btn btn-primary" type="submit">Salvar alterações</button></div></form></div>`);
  }

  async function openBriefing(leadId) {
    openModal(`${modalHeader('Superprompt JSON', 'Preparando briefing')}<div class="modal-body"><div class="empty-state scanning">Gerando ou carregando</div></div>`);
    try {
      let response = await api('/api/leads/' + leadId + '/briefing');
      if (!response.briefing) response = await api('/api/leads/' + leadId + '/briefing', jsonOptions('POST', {}));
      const lead = await api('/api/leads/' + leadId);
      state.modalLead = lead;
      showBriefingEditor(lead, response.briefing);
    } catch (error) { closeModal(); toast(error.message, 'error'); }
  }
  function showBriefingEditor(lead, briefing) {
    openModal(`${modalHeader('Superprompt JSON — ' + lead.name, 'JSON individual para Arena AI · válido e editável')}<div class="modal-body"><textarea class="json-editor" id="json-editor" spellcheck="false">${esc(JSON.stringify(briefing, null, 2))}</textarea><div id="json-status" class="json-status valid">JSON válido. Revise as pendências antes de usar na Arena AI.</div></div><div class="modal-footer"><button class="btn btn-ghost" data-action="details" data-id="${lead.id}">Voltar aos dados</button><button class="btn btn-ghost" data-action="regenerate-json" data-id="${lead.id}">Regerar</button><button class="btn btn-ghost" data-action="download-json" data-id="${lead.id}">Baixar</button><button class="btn btn-ghost" data-action="copy-json">Copiar JSON</button><button class="btn btn-primary" data-action="save-json" data-id="${lead.id}">Validar e salvar</button></div>`);
  }
  function editorObject() {
    const editor = $('#json-editor');
    if (!editor) throw new Error('Editor não encontrado');
    const value = JSON.parse(editor.value);
    const required = ['projeto', 'cliente', 'contatos_e_links', 'presenca_digital', 'informacoes_do_negocio', 'materiais_visuais', 'planejamento_do_site', 'verificacao'];
    const missing = required.filter(key => !(key in value));
    if (missing.length) throw new Error('Campos ausentes: ' + missing.join(', '));
    return value;
  }
  async function copyText(text) {
    if (!text) return toast('Não há conteúdo para copiar.', 'warning');
    try { await navigator.clipboard.writeText(text); }
    catch {
      const area = document.createElement('textarea'); area.value = text; document.body.appendChild(area); area.select(); document.execCommand('copy'); area.remove();
    }
    toast('Conteúdo copiado.');
  }
  function downloadJson(leadId) {
    try {
      const value = editorObject();
      const lead = state.allLeads.find(x => x.id === leadId) || state.modalLead;
      const blob = new Blob([JSON.stringify(value, null, 2) + '\n'], {type: 'application/json'});
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = (lead?.name || 'lead').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '') + '_arena_ai.json';
      link.click(); setTimeout(() => URL.revokeObjectURL(link.href), 1000);
      toast('JSON baixado.');
    } catch (error) { toast(error.message, 'error'); }
  }
  function updateLocalLead(lead) {
    const replace = items => items.map(x => x.id === lead.id ? lead : x);
    state.allLeads = replace(state.allLeads);
    state.leads = replace(state.leads);
    state.modalLead = lead;
  }

  document.addEventListener('click', async event => {
    const pageButton = event.target.closest('[data-page]');
    if (pageButton) { event.preventDefault(); navigate(pageButton.dataset.page); return; }
    const button = event.target.closest('[data-action]');
    if (!button) {
      if (event.target.classList.contains('modal-backdrop')) closeModal();
      return;
    }
    const action = button.dataset.action;
    const id = button.dataset.id;
    try {
      if (action === 'close-modal') closeModal();
      if (action === 'retry-load') navigate(state.page);
      if (action === 'clear-filters') { state.filters = {}; navigate(state.page); }
      if (action === 'open-search') { state.filters = {search_id: id}; navigate('results'); }
      if (action === 'cancel-research') { await api(`/api/research/${id}/cancel`, jsonOptions('POST', {})); toast('Cancelamento solicitado.', 'warning'); }
      if (action === 'details') openLead(id);
      if (action === 'edit-lead') openEditLead(state.modalLead || await api('/api/leads/' + id));
      if (action === 'briefing') openBriefing(id);
      if (action === 'copy-json') copyText($('#json-editor')?.value);
      if (action === 'copy-message') { const lead = state.allLeads.find(x => x.id === id) || state.modalLead || await api('/api/leads/' + id); copyText(lead.approach_message); }
      if (action === 'download-json') downloadJson(id);
      if (action === 'save-json') {
        const value = editorObject();
        const updated = await api('/api/leads/' + id, jsonOptions('PATCH', {briefing: value}));
        updateLocalLead(updated); $('#json-status').textContent = 'JSON válido e salvo no banco.'; $('#json-status').className = 'json-status valid'; toast('Briefing salvo.');
      }
      if (action === 'regenerate-json') {
        if (!confirm('Regerar o briefing a partir dos dados atuais? As edições manuais do JSON serão substituídas.')) return;
        const response = await api('/api/leads/' + id + '/briefing', jsonOptions('POST', {regenerate: true}));
        const lead = await api('/api/leads/' + id); updateLocalLead(lead); showBriefingEditor(lead, response.briefing); toast('Briefing regerado.');
      }
      if (action === 'save-lead') {
        const lead = state.allLeads.find(x => x.id === id) || state.modalLead || await api('/api/leads/' + id);
        const updated = await api(`/api/leads/${id}/save`, jsonOptions('POST', {saved: !lead.saved}));
        updateLocalLead(updated); toast(updated.saved ? 'Lead salvo.' : 'Lead removido dos salvos.');
        if ($('.modal')) openLead(id); else navigate(state.page);
      }
      if (action === 'potential-lead') {
        const lead = state.allLeads.find(x => x.id === id) || state.modalLead || await api('/api/leads/' + id);
        const updated = await api(`/api/leads/${id}/potential`, jsonOptions('POST', {potential_client: !lead.potential_client}));
        updateLocalLead(updated); toast(updated.potential_client ? 'Cliente potencial marcado.' : 'Marcação removida.');
        if ($('.modal')) openLead(id); else navigate(state.page);
      }
      if (action === 'delete-lead') {
        if (!confirm('Excluir definitivamente este lead e suas associações?')) return;
        await api('/api/leads/' + id, {method: 'DELETE'}); closeModal(); await refreshDashboard(); navigate(state.page); toast('Lead excluído.', 'warning');
      }
    } catch (error) { toast(error.message, 'error'); }
  });

  document.addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.target;
    try {
      if (form.id === 'login-form') {
        const button = $('button[type="submit"]', form); button.disabled = true; $('#login-error').textContent = '';
        try {
          const response = await api('/api/auth/login', jsonOptions('POST', {email: $('#login-email').value, password: $('#login-password').value}));
          state.user = response.user; state.csrf = response.csrf; await showApp();
        } catch (error) { $('#login-error').textContent = error.message; }
        finally { button.disabled = false; }
      }
      if (form.id === 'research-form') await startResearch(form);
      if (form.id === 'settings-form') {
        const data = new FormData(form);
        state.settings = await api('/api/settings', jsonOptions('PATCH', {default_desired_count: Number(data.get('default_desired_count')), results_per_page: Number(data.get('results_per_page')), default_min_followers: Number(data.get('default_min_followers')), default_max_followers: Number(data.get('default_max_followers')), reduced_motion: data.get('reduced_motion') === 'on'}));
        applyMotionPreference(); toast('Preferências salvas.');
      }
      if (form.id === 'password-form') {
        const data = new FormData(form);
        await api('/api/auth/password', jsonOptions('POST', {current_password: data.get('current_password'), new_password: data.get('new_password')}));
        state.user = null; state.csrf = null; showLogin(); toast('Senha alterada. Entre com a nova senha.');
      }
      if (form.id === 'note-form') {
        const data = new FormData(form);
        const updated = await api(`/api/leads/${form.dataset.id}/notes`, jsonOptions('POST', {note: data.get('note')}));
        updateLocalLead(updated); renderLeadModal(updated); toast('Observação adicionada.');
      }
      if (form.id === 'edit-lead-form') {
        const data = new FormData(form);
        const body = {};
        ['name', 'segment', 'neighborhood', 'city', 'region', 'address', 'instagram_url', 'whatsapp_number', 'whatsapp_url', 'site_url', 'maps_url', 'last_post_date', 'hours', 'commercial_analysis', 'approach_message', 'notes'].forEach(key => body[key] = data.get(key) || null);
        body.followers = data.get('followers') === '' ? null : Number(data.get('followers'));
        ['services', 'products', 'order_methods'].forEach(key => body[key] = String(data.get(key) || '').split('\n').map(x => x.trim()).filter(Boolean));
        const updated = await api('/api/leads/' + form.dataset.id, jsonOptions('PATCH', body));
        updateLocalLead(updated); await refreshDashboard(); renderLeadModal(updated); toast('Dados do lead atualizados.');
      }
    } catch (error) { toast(error.message, 'error'); }
  });

  document.addEventListener('change', async event => {
    const target = event.target;
    try {
      if (target.dataset.action === 'change-stage') {
        const updated = await api('/api/leads/' + target.dataset.id, jsonOptions('PATCH', {commercial_stage: target.value}));
        updateLocalLead(updated); toast('Etapa comercial atualizada.');
      }
      if (target.dataset.action === 'change-project') {
        const updated = await api('/api/leads/' + target.dataset.id, jsonOptions('PATCH', {project_status: target.value}));
        updateLocalLead(updated); toast('Status do projeto atualizado.');
      }
      if (target.id === 'filter-search') { state.filters.search_id = target.value; navigate(state.page); }
      if (target.id === 'filter-status') { state.filters.qualification_status = target.value; navigate(state.page); }
      if (target.id === 'filter-segment') { state.filters.segment = target.value; navigate(state.page); }
      if (target.id === 'filter-region') { state.filters.region = target.value; navigate(state.page); }
    } catch (error) { toast(error.message, 'error'); }
  });
  const filterDebounced = debounce(value => { state.filters.q = value; navigate(state.page); }, 450);
  document.addEventListener('input', event => { if (event.target.id === 'filter-q') filterDebounced(event.target.value); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') { if ($('.modal-backdrop')) closeModal(); $('#app').classList.remove('mobile-open'); } });

  $('#skip-intro').addEventListener('click', hideIntro);
  $('#collapse-sidebar').addEventListener('click', () => {
    $('#app').classList.toggle('sidebar-collapsed');
    localStorage.setItem('moon_sidebar_collapsed', $('#app').classList.contains('sidebar-collapsed') ? '1' : '0');
  });
  $('#mobile-menu').addEventListener('click', () => $('#app').classList.toggle('mobile-open'));
  $('#mobile-overlay').addEventListener('click', () => $('#app').classList.remove('mobile-open'));
  $('#logout-btn').addEventListener('click', async () => {
    try { await api('/api/auth/logout', jsonOptions('POST', {})); } catch { /* session may already be expired */ }
    state.user = null; state.csrf = null; clearInterval(state.pollTimer); showLogin();
  });

  async function init() {
    $$('[data-icon]').forEach(node => { node.innerHTML = icon(node.dataset.icon); });
    if (localStorage.getItem('moon_sidebar_collapsed') === '1') $('#app').classList.add('sidebar-collapsed');
    const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
    state.introTimer = setTimeout(hideIntro, reduced ? 50 : 2300);
    try {
      const session = await api('/api/auth/session');
      if (session.authenticated) { state.user = session.user; state.csrf = session.csrf; await showApp(); }
      else showLogin();
    } catch { showLogin(); }
  }
  init();
})();
