"""Deterministic commercial analysis and Arena AI briefing generation.

Only facts present in the lead dictionary are used as facts. Recommendations are
kept in planning fields and are explicitly labelled as suggestions.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from typing import Any


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _list(value: Any) -> list:
    return value if isinstance(value, list) else []


def niche_plan(segment: str | None) -> dict[str, list[str]]:
    text = (segment or '').lower()
    if any(word in text for word in ['hamburg', 'restaur', 'pizza', 'lanche', 'comida']):
        return {
            'secoes': ['Início', 'Cardápio confirmado', 'Categorias', 'Como pedir', 'Localização', 'Contato'],
            'funcionalidades': ['Cardápio digital com dados confirmados', 'Categorias e busca de itens', 'Botão de pedido no canal confirmado', 'Horários e retirada/entrega validados'],
            'oportunidade': 'organizar cardápio e pedidos em um canal próprio',
        }
    if any(word in text for word in ['doce', 'confeitar', 'bolo', 'sobremesa']):
        return {
            'secoes': ['Início', 'Produtos confirmados', 'Encomendas', 'Ocasiões', 'Localização', 'Contato'],
            'funcionalidades': ['Catálogo com fotos autorizadas', 'Formulário de encomenda', 'Prazos e retirada validados', 'CTA para canal comercial confirmado'],
            'oportunidade': 'organizar catálogo e encomendas com informações confirmadas',
        }
    if any(word in text for word in ['pet', 'cachorr', 'creche', 'veterin', 'hotel']):
        return {
            'secoes': ['Início', 'Serviços confirmados', 'Rotina e adaptação', 'FAQ', 'Localização', 'Contato'],
            'funcionalidades': ['Páginas por serviço confirmado', 'FAQ e requisitos validados', 'Formulário de pré-atendimento', 'CTA para WhatsApp confirmado'],
            'oportunidade': 'explicar serviços, rotina e contato em uma presença própria',
        }
    if any(word in text for word in ['barbear', 'estética', 'massagem', 'salão', 'beleza']):
        return {
            'secoes': ['Início', 'Serviços confirmados', 'Equipe', 'Agendamento', 'Localização', 'Contato'],
            'funcionalidades': ['Catálogo de serviços confirmados', 'Agendamento no canal disponível', 'Perfil da equipe com dados autorizados', 'Mapa e instruções de chegada'],
            'oportunidade': 'organizar serviços e agendamentos em uma jornada própria',
        }
    if any(word in text for word in ['academia', 'clínica', 'clinica', 'saúde', 'saude']):
        return {
            'secoes': ['Início', 'Serviços confirmados', 'Informações ao cliente', 'FAQ', 'Localização', 'Contato'],
            'funcionalidades': ['Apresentação de serviços sem alegações não confirmadas', 'Formulário de contato', 'Informações práticas validadas', 'Integração com canal de agendamento confirmado'],
            'oportunidade': 'organizar informações e contatos com clareza e conformidade',
        }
    return {
        'secoes': ['Início', 'Produtos ou serviços confirmados', 'Sobre', 'Localização', 'Contato'],
        'funcionalidades': ['Apresentação de produtos ou serviços confirmados', 'Formulário de contato', 'Mapa e instruções validadas', 'CTA no canal comercial confirmado'],
        'oportunidade': 'organizar informações e conversão em um canal próprio',
    }


def build_analysis(lead: dict[str, Any]) -> dict[str, Any]:
    """Build a specific, evidence-bound analysis without pretending to use AI."""
    name = lead.get('name') or 'A empresa'
    segment = lead.get('segment') or 'negócio local'
    strengths = list(_list(lead.get('strengths')))
    opportunities = list(_list(lead.get('opportunities')))
    followers = lead.get('followers')
    last_post = lead.get('last_post_date')
    if followers is not None:
        strengths.append(f'O perfil informado tem {followers:,} seguidores observados na data da pesquisa.'.replace(',', '.'))
    if last_post:
        strengths.append(f'Há publicação pública identificada em {last_post}.')
    if lead.get('rating') is not None and lead.get('review_count') is not None:
        strengths.append(f'O perfil do Maps exibia nota {lead["rating"]} e {lead["review_count"]} avaliações na coleta.')
    if lead.get('site_status') == 'VERIFICADO':
        strengths.append('O site associado ao negócio respondeu de forma compatível no teste.')
    if lead.get('whatsapp_status') == 'VERIFICADO':
        strengths.append('Há canal público de WhatsApp com titularidade sustentada pela fonte empresarial.')

    plan = niche_plan(segment)
    site_url = lead.get('site_url')
    site_status = lead.get('site_status')
    if not site_url:
        opportunities.append(f'Nenhum site oficial ativo foi confirmado; há oportunidade de {plan["oportunidade"]}. Isso não comprova que nenhum site exista.')
    elif site_status in {'INDISPONÍVEL', 'INCONSISTENTE', 'NÃO VERIFICADO'}:
        opportunities.append(f'O endereço de site apresentou status {site_status}; é uma oportunidade de diagnóstico e recuperação, não uma conclusão sobre a qualidade visual atual.')
    if lead.get('instagram_url') and not site_url:
        opportunities.append('A presença social identificada pode ganhar um destino próprio para informações e conversão, sem depender apenas da rede social.')
    if lead.get('reviews') and not lead.get('review_response_evidence'):
        opportunities.append('As avaliações podem orientar um diagnóstico de dúvidas e expectativas; relatos não devem ser transformados em promessas comerciais.')

    # Deduplicate while preserving order.
    strengths = list(dict.fromkeys(strengths))
    opportunities = list(dict.fromkeys(opportunities))
    evidence = []
    if followers is not None:
        evidence.append(f'{followers:,} seguidores observados'.replace(',', '.'))
    if last_post:
        evidence.append(f'publicação identificada em {last_post}')
    if site_url:
        evidence.append(f'site com status {site_status}')
    else:
        evidence.append('nenhum site oficial ativo confirmado')
    if lead.get('whatsapp_status') == 'VERIFICADO':
        evidence.append('WhatsApp verificado pela fonte empresarial')
    if lead.get('maps_status') == 'VERIFICADO':
        evidence.append('ficha específica do Maps verificada')
    if not evidence:
        evidence.append('informações públicas ainda limitadas')

    analysis = (
        f'{name}, no segmento de {segment}, foi analisada a partir de {", ".join(evidence)}. '
        + (f'O ponto mais concreto é {opportunities[0][0].lower() + opportunities[0][1:] if opportunities else "ampliar a verificação antes de propor um projeto"}. ')
        + 'A recomendação deve usar apenas serviços, materiais e canais confirmados; dados ausentes permanecem como pendências.'
    )
    message = None
    if lead.get('qualification_status') != 'NÃO QUALIFICADO':
        if not site_url:
            observation = 'não consegui confirmar um site oficial ativo nas fontes consultadas'
            proposal = f'uma página para {plan["oportunidade"]}'
        elif site_status == 'INDISPONÍVEL':
            observation = 'o endereço de site associado ao negócio não carregou no teste realizado'
            proposal = 'avaliar a recuperação desse canal e organizar as informações atuais'
        elif last_post or followers is not None:
            observation = 'o conteúdo público mostra atividade que pode ganhar um destino próprio'
            proposal = f'uma página para {plan["oportunidade"]}'
        else:
            observation = 'há informações públicas que podem ser melhor organizadas para o cliente'
            proposal = f'uma estrutura para {plan["oportunidade"]}'
        message = (
            f'Oi, equipe da {name}! Tudo bem? Conheci o trabalho de vocês pesquisando negócios da região. '
            f'Na análise, percebi que {observation}. Trabalho com a Moon Creative e vejo uma oportunidade de criar {proposal}, '
            'usando somente as informações e os materiais que vocês confirmarem. Posso mostrar uma ideia inicial, sem compromisso?'
        )
    return {
        'strengths': strengths,
        'opportunities': opportunities,
        'commercial_analysis': analysis,
        'approach_message': message,
        'recommended_sections': plan['secoes'],
        'recommended_features': plan['funcionalidades'],
    }


def build_briefing(lead: dict[str, Any]) -> dict[str, Any]:
    analysis = build_analysis(lead)
    other_links = deepcopy(_list(lead.get('other_links')))
    sources = deepcopy(_list(lead.get('sources')))
    problem_links = deepcopy(_list(lead.get('problem_links')))
    if not problem_links:
        for platform, prefix in [('instagram', 'instagram'), ('whatsapp', 'whatsapp'), ('site', 'site'), ('maps', 'maps')]:
            status = lead.get(f'{prefix}_status')
            url = lead.get(f'{prefix}_url')
            if status in {'INDISPONÍVEL', 'INCONSISTENTE', 'NÃO VERIFICADO'}:
                problem_links.append({'plataforma': platform, 'url': url, 'status': status})
    whatsapp_url = lead.get('whatsapp_url')
    ctas = []
    integrations = []
    if whatsapp_url and lead.get('whatsapp_status') == 'VERIFICADO':
        ctas.append({'tipo': 'WhatsApp', 'url': whatsapp_url, 'observacao': 'Usar somente após reconfirmar o canal antes da publicação.'})
        integrations.append({'tipo': 'WhatsApp', 'url': whatsapp_url})
    if lead.get('maps_url') and lead.get('maps_status') == 'VERIFICADO':
        integrations.append({'tipo': 'Google Maps', 'url': lead['maps_url']})
    if lead.get('instagram_url'):
        integrations.append({'tipo': 'Instagram', 'url': lead['instagram_url'], 'observacao': 'Não incorporar conteúdo sem autorização.'})

    unconfirmed = list(_list(lead.get('unconfirmed')))
    for field, label in [('followers', 'seguidores'), ('last_post_date', 'publicação mais recente'), ('hours', 'horários'), ('visual_identity', 'identidade visual')]:
        if lead.get(field) is None:
            unconfirmed.append(label)
    unconfirmed = list(dict.fromkeys(unconfirmed))
    project_objective = lead.get('site_objective')
    if not project_objective:
        project_objective = analysis['opportunities'][0] if analysis['opportunities'] else 'Definir o objetivo com o cliente após completar as pendências do briefing.'

    return {
        'projeto': {
            'agencia': 'Moon Creative',
            'tipo': 'Criação de site profissional',
            'plataforma': 'Arena AI',
            'objetivo': 'Desenvolver um site profissional, moderno e personalizado para a empresa prospectada.',
        },
        'cliente': {
            'nome': lead.get('name'),
            'segmento': lead.get('segment'),
            'descricao': lead.get('description'),
            'endereco': lead.get('address'),
            'cidade': lead.get('city'),
            'regiao': lead.get('region'),
        },
        'contatos_e_links': {
            'instagram': {'url': lead.get('instagram_url'), 'status': lead.get('instagram_status')},
            'whatsapp': {'numero': lead.get('whatsapp_number'), 'url': whatsapp_url, 'status': lead.get('whatsapp_status')},
            'site_atual': {'url': lead.get('site_url'), 'status': lead.get('site_status')},
            'google_maps': {'url': lead.get('maps_url'), 'status': lead.get('maps_status')},
            'outras_plataformas': other_links,
        },
        'presenca_digital': {
            'seguidores': lead.get('followers'),
            'publicacao_mais_recente': lead.get('last_post_date'),
            'frequencia_de_publicacao': lead.get('post_frequency'),
            'pontos_fortes': analysis['strengths'],
            'oportunidades': analysis['opportunities'],
        },
        'informacoes_do_negocio': {
            'produtos': deepcopy(_list(lead.get('products'))),
            'servicos': deepcopy(_list(lead.get('services'))),
            'precos': deepcopy(_list(lead.get('prices'))),
            'horarios': lead.get('hours'),
            'formas_de_pedido': deepcopy(_list(lead.get('order_methods'))),
            'diferenciais': deepcopy(_list(lead.get('differentials'))),
        },
        'materiais_visuais': {
            'logo': lead.get('logo'),
            'fotos': deepcopy(_list(lead.get('photos'))),
            'videos': deepcopy(_list(lead.get('videos'))),
            'cardapio_ou_catalogo': lead.get('menu_catalog'),
            'identidade_visual': lead.get('visual_identity'),
            'materiais_pendentes': deepcopy(_list(lead.get('materials_pending'))) or ['Logotipo, fotos, vídeos e autorizações de uso ainda não fornecidos.'],
        },
        'planejamento_do_site': {
            'objetivo': project_objective,
            'publico_alvo': lead.get('target_audience'),
            'conceito_visual': lead.get('visual_concept') or 'Definir direção personalizada com o cliente; não presumir paleta, logotipo ou estilo a partir do nome.',
            'paleta_de_cores': deepcopy(_list(lead.get('palette'))),
            'secoes': deepcopy(_list(lead.get('sections'))) or analysis['recommended_sections'],
            'funcionalidades': deepcopy(_list(lead.get('features'))) or analysis['recommended_features'],
            'chamadas_para_acao': ctas,
            'integracoes': integrations,
        },
        'verificacao': {
            'data_da_pesquisa': lead.get('research_date') or utcnow(),
            'fontes': sources,
            'dados_nao_confirmados': unconfirmed,
            'links_com_problemas': problem_links,
            'observacoes': list(_list(lead.get('verification_notes'))) + [
                f"Classificação do lead: {lead.get('qualification_status') or 'PARCIALMENTE VERIFICADO'}.",
                'A análise comercial e o planejamento são sugestões; não transformam recomendações em fatos sobre o negócio.',
            ],
        },
        'analise_comercial': {
            'texto': analysis['commercial_analysis'],
            'mensagem_de_abordagem_nao_enviada': analysis['approach_message'],
        },
        'instrucoes_visuais_e_tecnicas': {
            'direcao': 'Criar um projeto personalizado, premium e responsivo, sem copiar a identidade espacial da Moon Creative para o cliente, salvo solicitação explícita.',
            'obrigatorio': [
                'HTML semântico, acessibilidade, navegação por teclado e contraste adequado.',
                'Layout responsivo para desktop, tablet e celular.',
                'SEO técnico básico, metadados e dados estruturados somente com informações confirmadas.',
                'Desempenho, compressão de imagens autorizadas e respeito à redução de movimento.',
                'Não inventar textos, preços, produtos, serviços, depoimentos, fotos ou credenciais.',
                'Tratar campos null e pendências como perguntas ao cliente antes da publicação.',
                'Não utilizar avaliações ou imagens públicas como ativos autorizados.',
            ],
            'preparacao_para_arena': 'Use este JSON como briefing completo. Antes de gerar o site, apresente as pendências críticas e proponha a estrutura sem preencher lacunas por dedução.',
        },
    }


REQUIRED_BRIEFING_KEYS = {
    'projeto', 'cliente', 'contatos_e_links', 'presenca_digital',
    'informacoes_do_negocio', 'materiais_visuais', 'planejamento_do_site', 'verificacao'
}


def validate_briefing(value: Any) -> None:
    if not isinstance(value, dict):
        raise ValueError('O briefing precisa ser um objeto JSON.')
    missing = REQUIRED_BRIEFING_KEYS - set(value)
    if missing:
        raise ValueError(f'Campos obrigatórios ausentes: {sorted(missing)}')
    if not isinstance(value['projeto'], dict) or not isinstance(value['cliente'], dict):
        raise ValueError('As seções projeto e cliente precisam ser objetos JSON.')
    if value['projeto'].get('agencia') != 'Moon Creative':
        raise ValueError('O projeto precisa preservar a agência Moon Creative.')
    if not value['cliente'].get('nome'):
        raise ValueError('O briefing precisa identificar cliente.nome.')
