"""Optional OpenAI-compatible analysis enrichment.

The integration can only rewrite commercial text. Links, statuses, contacts and
qualification never pass through the AI and cannot be modified by its response.
"""
from __future__ import annotations

import json
import os
import re
from typing import Any

import requests


def configured() -> bool:
    return bool(os.environ.get('MOON_AI_API_KEY') and os.environ.get('MOON_AI_MODEL'))


def enrich_analysis(lead: dict[str, Any], base_analysis: dict[str, Any]) -> tuple[dict[str, Any], str, str | None]:
    if not configured():
        return base_analysis, 'deterministic', None
    facts = {
        'nome': lead.get('name'), 'segmento': lead.get('segment'), 'bairro': lead.get('neighborhood'),
        'cidade': lead.get('city'), 'seguidores': lead.get('followers'),
        'publicacao_mais_recente': lead.get('last_post_date'), 'site_status': lead.get('site_status'),
        'instagram_status': lead.get('instagram_status'), 'whatsapp_status': lead.get('whatsapp_status'),
        'maps_status': lead.get('maps_status'), 'nota': lead.get('rating'),
        'quantidade_avaliacoes': lead.get('review_count'), 'servicos_confirmados': lead.get('services'),
        'pontos_fortes_evidenciados': base_analysis.get('strengths'),
        'oportunidades_evidenciadas': base_analysis.get('opportunities'),
    }
    system = (
        'Você escreve análises comerciais para a Moon Creative. Use somente os fatos fornecidos. '
        'Não invente serviços, preços, identidade visual, atividade ou contatos. Não prometa resultados. '
        'Responda somente com um objeto JSON contendo strengths (array de strings), opportunities '
        '(array de strings), commercial_analysis (string) e approach_message (string curta, humana e não enviada).'
    )
    payload = {
        'model': os.environ['MOON_AI_MODEL'],
        'messages': [{'role': 'system', 'content': system}, {'role': 'user', 'content': json.dumps(facts, ensure_ascii=False)}],
        'temperature': 0.3,
        'response_format': {'type': 'json_object'},
    }
    url = os.environ.get('MOON_AI_BASE_URL', 'https://api.openai.com/v1/chat/completions')
    try:
        response = requests.post(url, headers={'Authorization': 'Bearer ' + os.environ['MOON_AI_API_KEY'], 'Content-Type': 'application/json'}, json=payload, timeout=35)
        if response.status_code != 200:
            return base_analysis, 'deterministic', f'IA retornou HTTP {response.status_code}; análise determinística preservada.'
        data = response.json()
        content = data['choices'][0]['message']['content']
        content = re.sub(r'^```(?:json)?\s*|\s*```$', '', content.strip())
        candidate = json.loads(content)
        merged = dict(base_analysis)
        for key in ['strengths', 'opportunities']:
            if isinstance(candidate.get(key), list) and all(isinstance(x, str) for x in candidate[key]):
                merged[key] = candidate[key][:8]
        for key in ['commercial_analysis', 'approach_message']:
            if isinstance(candidate.get(key), str) and candidate[key].strip():
                merged[key] = candidate[key].strip()[:4000]
        return merged, 'ai', None
    except (requests.RequestException, KeyError, IndexError, TypeError, json.JSONDecodeError) as exc:
        return base_analysis, 'deterministic', f'Falha na integração de IA ({type(exc).__name__}); análise determinística preservada.'
