from __future__ import annotations

import argparse
import hmac
import json
import mimetypes
import os
import re
import threading
import time
import uuid
from collections import defaultdict
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import store
from briefing import build_briefing, validate_briefing
from research import run_research

BASE_DIR = Path(__file__).resolve().parent.parent
FRONTEND_DIR = BASE_DIR / 'frontend'
SEED_FILE = BASE_DIR / 'data' / 'seed_data.json'
TASKS = {}
TASK_LOCK = threading.Lock()
LOGIN_ATTEMPTS = defaultdict(list)
STAGES = ['Novo lead', 'Lead analisado', 'Contato realizado', 'Aguardando resposta', 'Interessado', 'Reunião ou negociação', 'Cliente fechado', 'Não interessado']
PROJECT_STATUSES = ['NÃO INICIADO', 'BRIEFING PRONTO', 'PROJETO PREPARADO', 'SITE GERADO']


def import_seed() -> None:
    if not SEED_FILE.exists() or store.row_one('SELECT COUNT(*) AS total FROM leads')['total']:
        return
    data = json.loads(SEED_FILE.read_text(encoding='utf-8'))
    params = data['search']
    search_id = store.create_search(params, data['search'].get('provider', 'historical_import'))
    for lead in data['leads']:
        store.upsert_lead(lead, search_id)
    store.recalc_search_counts(search_id)
    store.update_search(search_id, status='completed', progress=100, current_step='Pesquisa histórica importada', created_at=params.get('created_at') or store.utcnow())
    store.add_search_event(search_id, f"{len(data['leads'])} empresas importadas da prospecção verificada; nenhum contato comercial foi realizado.", progress=100)


def integration_state() -> dict:
    google_places = bool(os.environ.get('GOOGLE_PLACES_API_KEY'))
    cse = bool(os.environ.get('GOOGLE_CSE_API_KEY') and os.environ.get('GOOGLE_CSE_CX'))
    ai = bool(os.environ.get('MOON_AI_API_KEY') and os.environ.get('MOON_AI_MODEL'))
    return {
        'google_places': {'configured': google_places, 'label': 'Google Places', 'note': 'Descoberta, Maps, telefone, site e avaliações via API oficial.' if google_places else 'Configure GOOGLE_PLACES_API_KEY no backend.'},
        'google_cse': {'configured': cse, 'label': 'Google Custom Search', 'note': 'Busca web complementar configurada.' if cse else 'Opcional: GOOGLE_CSE_API_KEY e GOOGLE_CSE_CX.'},
        'openstreetmap': {'configured': True, 'label': 'OpenStreetMap', 'note': 'Nominatim/Overpass disponíveis para pesquisa pública real; não gera ficha ou avaliações do Google.'},
        'ai_analysis': {'configured': ai, 'label': 'Enriquecimento por IA', 'note': 'IA configurada; links e status permanecem fora do modelo.' if ai else 'Análise determinística ativa. Configure MOON_AI_API_KEY e MOON_AI_MODEL para enriquecer textos.'},
        'active_provider': 'google_places' if google_places else 'openstreetmap',
    }


class Handler(BaseHTTPRequestHandler):
    server_version = 'MoonProspecting/1.0'

    def log_message(self, fmt, *args):
        print(f'[{self.log_date_time_string()}] {fmt % args}', flush=True)

    def end_headers(self):
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        origin = self.headers.get('Origin')
        allowed = {x.strip() for x in os.environ.get('ALLOWED_ORIGINS', '').split(',') if x.strip()}
        if origin and origin in allowed:
            self.send_header('Access-Control-Allow-Origin', origin)
            self.send_header('Access-Control-Allow-Credentials', 'true')
            self.send_header('Vary', 'Origin')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header('Access-Control-Allow-Methods', 'GET,POST,PATCH,DELETE,OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type,X-CSRF-Token')
        self.send_header('Access-Control-Max-Age', '600')
        self.end_headers()

    def do_GET(self):
        self.dispatch('GET')

    def do_POST(self):
        self.dispatch('POST')

    def do_PATCH(self):
        self.dispatch('PATCH')

    def do_DELETE(self):
        self.dispatch('DELETE')

    def do_HEAD(self):
        self.dispatch('HEAD')

    def dispatch(self, method):
        try:
            parsed = urlparse(self.path)
            if parsed.path.startswith('/api/'):
                self.handle_api(method, parsed)
            elif method in {'GET', 'HEAD'}:
                self.serve_static(parsed.path)
            else:
                self.send_json({'error': 'Método não permitido'}, 405)
        except ValueError as exc:
            self.send_json({'error': str(exc)}, 400)
        except json.JSONDecodeError:
            self.send_json({'error': 'JSON inválido'}, 400)
        except Exception as exc:
            print(f'API error: {type(exc).__name__}: {exc}', flush=True)
            self.send_json({'error': 'Erro interno processando a solicitação', 'type': type(exc).__name__}, 500)

    def send_json(self, value, status=200, extra_headers=None):
        payload = json.dumps(value, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.send_header('Cache-Control', 'no-store')
        for key, val in (extra_headers or {}).items():
            self.send_header(key, val)
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(payload)

    def read_json(self):
        length = int(self.headers.get('Content-Length') or 0)
        if length <= 0:
            return {}
        if length > 2_000_000:
            raise ValueError('Payload acima do limite permitido')
        value = json.loads(self.rfile.read(length).decode('utf-8'))
        if not isinstance(value, dict):
            raise ValueError('O corpo da requisição precisa ser um objeto JSON')
        return value

    def session_token(self):
        cookie = SimpleCookie(self.headers.get('Cookie'))
        return cookie['moon_session'].value if 'moon_session' in cookie else None

    def session(self, required=True):
        session = store.get_session(self.session_token())
        if required and not session:
            self.send_json({'error': 'Autenticação necessária'}, 401)
            return None
        return session

    def check_csrf(self, session):
        token = self.headers.get('X-CSRF-Token', '')
        if not session or not hmac.compare_digest(token, session['csrf_token']):
            self.send_json({'error': 'Token CSRF ausente ou inválido'}, 403)
            return False
        return True

    def cookie_for(self, token, expires=False):
        parts = [f'moon_session={token}', 'Path=/', 'HttpOnly', 'Max-Age=' + ('0' if expires else '43200')]
        same_site = os.environ.get('COOKIE_SAMESITE', 'Lax')
        parts.append('SameSite=' + same_site)
        if os.environ.get('COOKIE_SECURE') == '1' or self.headers.get('X-Forwarded-Proto') == 'https' or same_site == 'None':
            parts.append('Secure')
        return '; '.join(parts)

    def handle_api(self, method, parsed):
        path = parsed.path
        query = parse_qs(parsed.query)
        if path == '/api/health' and method == 'GET':
            return self.send_json({'ok': True, 'service': 'Moon Creative — Prospecting Intelligence', 'time': store.utcnow(), 'provider': integration_state()['active_provider']})
        if path == '/api/auth/login' and method == 'POST':
            return self.login()
        if path == '/api/auth/session' and method == 'GET':
            session = self.session(required=False)
            if not session:
                return self.send_json({'authenticated': False})
            return self.send_json({'authenticated': True, 'user': {'email': session['email']}, 'csrf': session['csrf_token'], 'expires_at': session['expires_at']})
        session = self.session()
        if not session:
            return
        if method in {'POST', 'PATCH', 'DELETE'} and not self.check_csrf(session):
            return

        if path == '/api/auth/logout' and method == 'POST':
            store.delete_session(self.session_token())
            return self.send_json({'ok': True}, extra_headers={'Set-Cookie': self.cookie_for('', True)})
        if path == '/api/auth/password' and method == 'POST':
            body = self.read_json()
            new = body.get('new_password') or ''
            if len(new) < 12:
                raise ValueError('A nova senha precisa ter ao menos 12 caracteres')
            if not store.change_password(session['owner_id'], body.get('current_password') or '', new):
                return self.send_json({'error': 'Senha atual incorreta'}, 400)
            return self.send_json({'ok': True, 'message': 'Senha alterada. Entre novamente.'}, extra_headers={'Set-Cookie': self.cookie_for('', True)})
        if path == '/api/dashboard' and method == 'GET':
            return self.send_json(store.dashboard())
        if path == '/api/integrations' and method == 'GET':
            return self.send_json(integration_state())
        if path == '/api/activities' and method == 'GET':
            return self.send_json({'activities': store.recent_activities(30)})
        if path == '/api/settings':
            if method == 'GET':
                return self.send_json(store.get_settings())
            if method == 'PATCH':
                return self.send_json(store.update_settings(self.read_json()))
        if path == '/api/research':
            if method == 'GET':
                return self.send_json({'searches': store.list_searches(100)})
            if method == 'POST':
                return self.start_research()
        match = re.fullmatch(r'/api/research/([0-9a-f-]+)(/cancel)?', path)
        if match:
            search_id, cancel = match.group(1), match.group(2)
            search = store.get_search(search_id)
            if not search:
                return self.send_json({'error': 'Pesquisa não encontrada'}, 404)
            if method == 'GET' and not cancel:
                return self.send_json(search)
            if method == 'POST' and cancel:
                if search['status'] not in {'queued', 'running', 'cancelling'}:
                    return self.send_json({'error': 'Somente pesquisas ativas podem ser canceladas'}, 409)
                if search['status'] == 'cancelling':
                    return self.send_json({'ok': True, 'status': 'cancelling'})
                with TASK_LOCK:
                    task = TASKS.get(search_id)
                    alive = bool(task and task['thread'].is_alive())
                    if alive:
                        task['cancel'].set()
                if alive:
                    store.update_search(search_id, status='cancelling', current_step='Cancelamento solicitado')
                    store.add_search_event(search_id, 'Cancelamento solicitado pelo usuário.', 'warning')
                else:
                    store.update_search(search_id, status='cancelled', current_step='Pesquisa cancelada; não havia worker ativo.')
                    store.add_search_event(search_id, 'Pesquisa cancelada; não havia worker ativo.', 'warning')
                return self.send_json({'ok': True})
        if path == '/api/leads' and method == 'GET':
            filters = {key: values[0] for key, values in query.items() if values}
            for key in ['saved', 'potential_client']:
                if key in filters:
                    filters[key] = filters[key].lower() in {'1', 'true', 'yes'}
            leads = store.list_leads(filters)
            return self.send_json({'leads': leads, 'total': len(leads)})
        match = re.fullmatch(r'/api/leads/([A-Za-z0-9_-]+)(/briefing|/save|/potential|/notes)?', path)
        if match:
            lead_id, action = match.group(1), match.group(2)
            lead = store.get_lead(lead_id)
            if not lead:
                return self.send_json({'error': 'Lead não encontrado'}, 404)
            if method == 'GET' and not action:
                return self.send_json(lead)
            if method == 'DELETE' and not action:
                store.delete_lead(lead_id)
                return self.send_json({'ok': True})
            if method == 'PATCH' and not action:
                body = self.read_json()
                if 'commercial_stage' in body and body['commercial_stage'] not in STAGES:
                    raise ValueError('Etapa comercial inválida')
                if 'project_status' in body and body['project_status'] not in PROJECT_STATUSES:
                    raise ValueError('Status de projeto inválido')
                if 'name' in body and not str(body['name']).strip():
                    raise ValueError('O nome não pode ficar vazio')
                if 'briefing' in body:
                    validate_briefing(body['briefing'])
                    expected_name = body.get('name') or lead['name']
                    if body['briefing']['cliente'].get('nome') != expected_name:
                        raise ValueError('O briefing não pode misturar empresas: cliente.nome diverge do lead')
                updated = store.update_lead(lead_id, body)
                return self.send_json(updated)
            if method == 'POST' and action == '/save':
                body = self.read_json()
                saved = bool(body.get('saved'))
                updated = store.update_lead(lead_id, {'saved': saved}, 'organizacao', 'Lead salvo' if saved else 'Lead removido dos salvos')
                return self.send_json(updated)
            if method == 'POST' and action == '/potential':
                body = self.read_json()
                potential = bool(body.get('potential_client'))
                updated = store.update_lead(lead_id, {'potential_client': potential}, 'organizacao', 'Marcado como cliente potencial' if potential else 'Marcação de cliente potencial removida')
                return self.send_json(updated)
            if method == 'POST' and action == '/notes':
                body = self.read_json()
                note = str(body.get('note') or '').strip()
                if not note:
                    raise ValueError('Escreva uma observação')
                notes = (lead.get('notes') or '').strip()
                stamped = f'[{store.utcnow()}] {note}'
                updated = store.update_lead(lead_id, {'notes': (notes + '\n' + stamped).strip()}, 'observacao', note)
                return self.send_json(updated)
            if action == '/briefing':
                if method == 'GET':
                    return self.send_json({'briefing': lead.get('briefing')})
                if method == 'POST':
                    body = self.read_json()
                    if lead.get('briefing') and not body.get('regenerate'):
                        return self.send_json({'briefing': lead['briefing']})
                    briefing = build_briefing(lead)
                    project_status = lead.get('project_status') if lead.get('project_status') != 'NÃO INICIADO' else 'BRIEFING PRONTO'
                    updated = store.update_lead(lead_id, {'briefing': briefing, 'project_status': project_status}, 'briefing', 'Superprompt JSON gerado para Arena AI')
                    return self.send_json({'briefing': updated['briefing']})
        self.send_json({'error': 'Endpoint não encontrado'}, 404)

    def login(self):
        ip = self.headers.get('X-Forwarded-For', self.client_address[0]).split(',')[0].strip()
        now = time.time()
        LOGIN_ATTEMPTS[ip] = [t for t in LOGIN_ATTEMPTS[ip] if now - t < 300]
        if len(LOGIN_ATTEMPTS[ip]) >= 8:
            return self.send_json({'error': 'Muitas tentativas. Aguarde alguns minutos.'}, 429)
        body = self.read_json()
        user = store.verify_login(str(body.get('email') or ''), str(body.get('password') or ''))
        if not user:
            LOGIN_ATTEMPTS[ip].append(now)
            time.sleep(0.4)
            return self.send_json({'error': 'E-mail ou senha incorretos'}, 401)
        LOGIN_ATTEMPTS[ip].clear()
        token, csrf, expires = store.create_session(user['id'])
        return self.send_json({'authenticated': True, 'user': {'email': user['email']}, 'csrf': csrf, 'expires_at': expires}, extra_headers={'Set-Cookie': self.cookie_for(token)})

    def start_research(self):
        body = self.read_json()
        niche = str(body.get('niche') or '').strip()
        if len(niche) < 2 or len(niche) > 120:
            raise ValueError('Informe um nicho entre 2 e 120 caracteres')
        desired = int(body.get('desired_count') or 20)
        if desired < 1 or desired > 50:
            raise ValueError('A quantidade precisa estar entre 1 e 50')
        min_f = body.get('min_followers')
        max_f = body.get('max_followers')
        min_f = int(min_f) if min_f not in {None, ''} else None
        max_f = int(max_f) if max_f not in {None, ''} else None
        if min_f is not None and min_f < 0 or max_f is not None and max_f < 0:
            raise ValueError('Seguidores não podem ser negativos')
        if min_f is not None and max_f is not None and min_f > max_f:
            raise ValueError('A faixa mínima não pode ser maior que a máxima')
        with TASK_LOCK:
            running = [x for x in TASKS.values() if x['thread'].is_alive()]
            if len(running) >= 3:
                return self.send_json({'error': 'Há três pesquisas ativas. Aguarde ou cancele uma delas.'}, 409)
        params = {
            'region': str(body.get('region') or '').strip()[:120] or None,
            'neighborhood': str(body.get('neighborhood') or '').strip()[:120] or None,
            'city': str(body.get('city') or '').strip()[:120] or None,
            'niche': niche, 'desired_count': desired, 'min_followers': min_f, 'max_followers': max_f,
            'criteria': body.get('criteria') if isinstance(body.get('criteria'), dict) else {},
        }
        if params['criteria'].get('notes'):
            params['criteria']['notes'] = str(params['criteria']['notes'])[:500]
        search_id = store.create_search(params, 'auto')
        cancel = threading.Event()
        thread = threading.Thread(target=run_research, args=(search_id, params, cancel), daemon=True, name=f'research-{search_id[:8]}')
        with TASK_LOCK:
            TASKS[search_id] = {'thread': thread, 'cancel': cancel}
        thread.start()
        return self.send_json(store.get_search(search_id), 202)

    def serve_static(self, path):
        requested = path.lstrip('/') or 'index.html'
        if requested == 'favicon.ico':
            requested = 'favicon.svg'
        candidate = (FRONTEND_DIR / requested).resolve()
        if not candidate.is_relative_to(FRONTEND_DIR.resolve()):
            return self.send_json({'error': 'Caminho inválido'}, 403)
        if not candidate.is_file():
            if '.' not in Path(requested).name:
                candidate = FRONTEND_DIR / 'index.html'
            else:
                return self.send_json({'error': 'Arquivo não encontrado'}, 404)
        content = candidate.read_bytes()
        mime = mimetypes.guess_type(candidate.name)[0] or 'application/octet-stream'
        if candidate.suffix == '.js':
            mime = 'text/javascript'
        self.send_response(200)
        self.send_header('Content-Type', mime + ('; charset=utf-8' if mime.startswith('text/') or mime in {'application/javascript', 'application/json'} else ''))
        self.send_header('Content-Length', str(len(content)))
        self.send_header('Cache-Control', 'no-cache' if candidate.name == 'index.html' else 'public, max-age=300')
        self.send_header('Content-Security-Policy', "default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self' https:; font-src 'self' data:; object-src 'none'; base-uri 'self'; form-action 'self'")
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(content)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=int(os.environ.get('PORT', '8000')))
    args = parser.parse_args()
    store.init_db()
    recovered = store.recover_interrupted_searches()
    if recovered:
        print(f'{recovered} pesquisa(s) interrompida(s) foram marcadas como canceladas.', flush=True)
    email, generated = store.ensure_owner()
    import_seed()
    server = ThreadingHTTPServer(('0.0.0.0', args.port), Handler)
    server.daemon_threads = True
    print(f'Moon Creative — Prospecting Intelligence em 0.0.0.0:{args.port}', flush=True)
    print(f'Proprietário: {email}. Credenciais iniciais em data/OWNER_ACCESS.txt' if generated else f'Proprietário: {email}', flush=True)
    print(f'Provedor ativo: {integration_state()["active_provider"]}', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        with TASK_LOCK:
            for task in TASKS.values():
                task['cancel'].set()
        server.server_close()


if __name__ == '__main__':
    main()
