from __future__ import annotations

import html
import ipaddress
import json
import os
import re
import socket
import threading
import time
import unicodedata
from datetime import datetime, timezone
from typing import Any
from urllib.parse import parse_qs, urljoin, urlparse

import requests

import store
from briefing import build_analysis, build_briefing
from ai import enrich_analysis, configured as ai_configured

USER_AGENT = os.environ.get('MOON_OSM_USER_AGENT', 'MoonCreativeProspectingIntelligence/1.0 (private internal research)')
OSM_RATE_LOCK = threading.Lock()
OSM_LAST_CALL = [0.0]
ALLOWED_LINK_STATUSES = {'VERIFICADO', 'IDENTIDADE CONFIRMADA, ACESSO NÃO TESTADO', 'NÃO VERIFICADO', 'INDISPONÍVEL', 'INCONSISTENTE'}


class ResearchCancelled(Exception):
    pass


class ResearchError(Exception):
    pass


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def ascii_text(value: str | None) -> str:
    return ''.join(c for c in unicodedata.normalize('NFKD', value or '') if not unicodedata.combining(c)).lower()


def normalize_br_phone(value: str | None) -> tuple[str | None, str | None]:
    if not value:
        return None, None
    digits = re.sub(r'\D', '', value)
    digits = digits.lstrip('0')
    if digits.startswith('55') and len(digits) in {12, 13}:
        national = digits[2:]
    elif len(digits) in {10, 11}:
        national = digits
    else:
        return None, None
    if len(national) not in {10, 11} or national[:2] == '00':
        return None, None
    e164 = '+55' + national
    return e164, 'https://wa.me/55' + national


def canonical_instagram(value: str | None) -> str | None:
    if not value:
        return None
    value = value.strip()
    if not value:
        return None
    if value.startswith('@'):
        value = value[1:]
    if 'instagram.com' not in value:
        if re.fullmatch(r'[A-Za-z0-9._]{2,30}', value):
            return f'https://www.instagram.com/{value}/'
        return None
    if not value.startswith('http'):
        value = 'https://' + value.lstrip('/')
    parsed = urlparse(value)
    host = (parsed.hostname or '').lower()
    if host not in {'instagram.com', 'www.instagram.com'}:
        return None
    parts = [p for p in parsed.path.split('/') if p]
    if len(parts) != 1 or parts[0].lower() in {'p', 'reel', 'reels', 'stories', 'explore', 'accounts', 'direct'}:
        return None
    handle = parts[0]
    if not re.fullmatch(r'[A-Za-z0-9._]{2,30}', handle):
        return None
    return f'https://www.instagram.com/{handle}/'


def _public_host(host: str) -> bool:
    if os.environ.get('ALLOW_PRIVATE_URLS') == '1':
        return True
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        return False
    for info in infos:
        address = info[4][0]
        try:
            ip = ipaddress.ip_address(address)
        except ValueError:
            return False
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved or ip.is_unspecified:
            return False
    return True


def safe_url(url: str | None) -> str | None:
    if not url:
        return None
    try:
        parsed = urlparse(url if '://' in url else 'https://' + url)
    except ValueError:
        return None
    if parsed.scheme not in {'http', 'https'} or not parsed.hostname or parsed.username or parsed.password:
        return None
    if not _public_host(parsed.hostname):
        return None
    return parsed.geturl()


def _text_from_html(content: str) -> str:
    content = re.sub(r'(?is)<(script|style).*?>.*?</\1>', ' ', content)
    content = re.sub(r'(?s)<[^>]+>', ' ', content)
    return re.sub(r'\s+', ' ', html.unescape(content)).strip()


def _title_from_html(content: str) -> str | None:
    for pattern in [r'(?is)<meta[^>]+property=["\']og:title["\'][^>]+content=["\'](.*?)["\']', r'(?is)<title[^>]*>(.*?)</title>']:
        match = re.search(pattern, content)
        if match:
            return re.sub(r'\s+', ' ', html.unescape(match.group(1))).strip()[:300]
    return None


def _name_matches(name: str, content: str) -> bool:
    tokens = [ascii_text(t) for t in re.findall(r'[A-Za-zÀ-ÿ0-9]{4,}', name or '')]
    tokens = [t for t in tokens if t not in {'hotel', 'creche', 'petshop', 'restaurante', 'clinica'}]
    if not tokens:
        return False
    haystack = ascii_text(content)
    return any(token in haystack for token in tokens)


def _parse_followers(content: str) -> int | None:
    patterns = [
        r'([\d.,]+\s*[KMkm]?)\s+(?:followers|seguidores)',
        r'([\d.,]+\s*[KMkm]?)\s+Followers',
    ]
    match = re.search(patterns[0], content, re.I) or re.search(patterns[1], content, re.I)
    if not match:
        return None
    raw = match.group(1).replace(' ', '')
    multiplier = 1
    if raw[-1:].upper() == 'K':
        multiplier = 1000
        raw = raw[:-1]
    elif raw[-1:].upper() == 'M':
        multiplier = 1000000
        raw = raw[:-1]
    try:
        if ',' in raw and '.' in raw:
            number = float(raw.replace('.', '').replace(',', '.'))
        elif ',' in raw:
            number = float(raw.replace(',', '.'))
        elif '.' in raw and raw.count('.') == 1 and len(raw.split('.')[-1]) <= 2 and multiplier > 1:
            number = float(raw)
        else:
            number = float(raw.replace('.', '').replace(',', ''))
        return int(number * multiplier)
    except ValueError:
        return None


def platform_for_url(url: str) -> str:
    host = (urlparse(url).hostname or '').lower()
    if 'instagram.com' in host:
        return 'Instagram'
    if 'facebook.com' in host or 'fb.com' in host:
        return 'Facebook'
    if 'tiktok.com' in host:
        return 'TikTok'
    if 'ifood.com' in host:
        return 'iFood'
    if '99food' in host:
        return '99Food'
    if 'keeta' in host:
        return 'Keeta'
    if 'wa.me' in host or 'whatsapp.com' in host or 'wa.link' in host:
        return 'WhatsApp'
    if 'openstreetmap.org' in host:
        return 'OpenStreetMap'
    return host or 'Link externo'


class LinkVerifier:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({'User-Agent': USER_AGENT, 'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.5'})

    def fetch(self, url: str, max_bytes: int = 450_000, timeout: int = 9) -> dict[str, Any]:
        current = safe_url(url)
        if not current:
            return {'url': url, 'status': 'NÃO VERIFICADO', 'http_status': None, 'error': 'URL inválida, local ou não pública', 'content': '', 'final_url': None}
        try:
            for redirect in range(6):
                response = self.session.get(current, timeout=(4, timeout), allow_redirects=False, stream=True)
                if response.is_redirect or response.is_permanent_redirect:
                    location = response.headers.get('Location')
                    response.close()
                    if not location:
                        break
                    current = safe_url(urljoin(current, location))
                    if not current:
                        return {'url': url, 'status': 'INCONSISTENTE', 'http_status': None, 'error': 'Redirecionamento para endereço não público', 'content': '', 'final_url': None}
                    continue
                chunks = []
                size = 0
                for chunk in response.iter_content(16384):
                    if not chunk:
                        continue
                    chunks.append(chunk)
                    size += len(chunk)
                    if size >= max_bytes:
                        break
                raw = b''.join(chunks[:])
                encoding = response.encoding or 'utf-8'
                content = raw.decode(encoding, errors='replace')
                result = {
                    'url': url, 'final_url': current, 'http_status': response.status_code,
                    'content': content, 'title': _title_from_html(content),
                    'text': _text_from_html(content)[:8000], 'error': None,
                    'headers': {k.lower(): v for k, v in response.headers.items() if k.lower() in {'content-type', 'location'}},
                }
                response.close()
                return result
            return {'url': url, 'status': 'INDISPONÍVEL', 'http_status': None, 'error': 'Excesso de redirecionamentos', 'content': '', 'final_url': current}
        except requests.RequestException as exc:
            return {'url': url, 'status': 'INDISPONÍVEL', 'http_status': None, 'error': f'{type(exc).__name__}: {str(exc)[:240]}', 'content': '', 'final_url': current}

    def verify(self, url: str | None, business_name: str, source_description: str, identity_from_source: bool = False) -> dict[str, Any]:
        base = {'url': url, 'fonte': source_description, 'verificado_em': utcnow()}
        if not url:
            return {**base, 'status': 'NÃO VERIFICADO', 'observacao': 'Endereço não localizado; ausência de informação não foi tratada como erro.'}
        fetched = self.fetch(url)
        code = fetched.get('http_status')
        content = fetched.get('content') or ''
        text = (fetched.get('title') or '') + ' ' + (fetched.get('text') or '')
        match = _name_matches(business_name, text)
        if code and 200 <= code < 400:
            # A source-associated WhatsApp number is a separate evidence path: its
            # page often does not contain the business name. Other links need a
            # content/name match; HTTP 200 alone is never identity verification.
            whatsapp_source = 'número associado' in source_description.lower() or 'numero associado' in source_description.lower()
            verified = bool(match or (identity_from_source and whatsapp_source))
            status = 'VERIFICADO' if verified else 'NÃO VERIFICADO'
            note = ('Acesso compatível e identidade sustentada pela fonte.' if verified and whatsapp_source else
                    'Acesso e nome compatíveis.' if verified else 'Acesso respondeu, mas o conteúdo não confirmou a identidade.')
        elif code in {401, 403, 429}:
            status = 'INDISPONÍVEL'
            note = f'Acesso limitado por HTTP {code}; não significa inexistência.'
        elif code:
            status = 'INDISPONÍVEL'
            note = f'Endereço testado com HTTP {code}.'
        else:
            status = fetched.get('status') or 'INDISPONÍVEL'
            note = fetched.get('error') or 'Falha de acesso.'
        return {
            **base, 'status': status, 'http_status': code, 'final_url': fetched.get('final_url'),
            'title': fetched.get('title'), 'identidade_por_conteudo': match,
            'observacao': note, 'conteudo': content,
        }


class ResearchEngine:
    def __init__(self, search_id: str, params: dict[str, Any], cancel_event: threading.Event):
        self.search_id = search_id
        self.params = params
        self.cancel_event = cancel_event
        self.verifier = LinkVerifier()
        self.google_key = os.environ.get('GOOGLE_PLACES_API_KEY')
        self.cse_key = os.environ.get('GOOGLE_CSE_API_KEY')
        self.cse_cx = os.environ.get('GOOGLE_CSE_CX')
        self.provider = 'google_places' if self.google_key else 'openstreetmap'

    def check_cancel(self):
        if self.cancel_event.is_set():
            raise ResearchCancelled()

    def event(self, message: str, level: str = 'info', progress: int | None = None):
        store.add_search_event(self.search_id, message, level, progress)

    def run(self):
        store.update_search(self.search_id, status='running', provider=self.provider, progress=2, error=None)
        self.event(f'Motor iniciado com provedor {self.provider}.', progress=2)
        try:
            candidates = self.discover()
            self.check_cancel()
            desired = int(self.params['desired_count'])
            candidates = candidates[:desired]
            if not candidates:
                self.event('Nenhuma empresa correspondente foi retornada pela fonte real. Nenhum lead fictício foi criado.', 'warning', 100)
                store.update_search(self.search_id, status='completed', progress=100, current_step='Pesquisa concluída sem resultados')
                return
            self.event(f'{len(candidates)} empresas encontradas; iniciando verificação individual.', progress=8)
            for index, candidate in enumerate(candidates, 1):
                self.check_cancel()
                progress = 8 + int((index - 1) / len(candidates) * 88)
                self.event(f'Verificando {candidate.get("name") or "empresa"} ({index}/{len(candidates)})', progress=progress)
                try:
                    lead = self.process_candidate(candidate)
                    if lead:
                        store.upsert_lead(lead, self.search_id)
                        store.recalc_search_counts(self.search_id)
                except ResearchCancelled:
                    raise
                except Exception as exc:
                    self.event(f'Falha ao processar {candidate.get("name") or "empresa"}: {type(exc).__name__}: {str(exc)[:180]}', 'error')
            self.check_cancel()
            store.recalc_search_counts(self.search_id)
            self.event('Pesquisa concluída com dados reais e limitações registradas.', progress=100)
            store.update_search(self.search_id, status='completed', progress=100, current_step='Pesquisa concluída')
        except ResearchCancelled:
            store.recalc_search_counts(self.search_id)
            self.event('Pesquisa cancelada pelo usuário; resultados já processados foram preservados.', 'warning')
            store.update_search(self.search_id, status='cancelled', current_step='Pesquisa cancelada')
        except Exception as exc:
            self.event(f'Pesquisa interrompida: {type(exc).__name__}: {str(exc)[:300]}', 'error')
            store.update_search(self.search_id, status='failed', error=f'{type(exc).__name__}: {str(exc)[:500]}', current_step='Falha na pesquisa')

    def discover(self) -> list[dict[str, Any]]:
        self.check_cancel()
        if self.provider == 'google_places':
            try:
                return self.discover_google_places()
            except Exception as exc:
                self.event(f'Google Places falhou: {str(exc)[:180]}. Nenhum resultado será inventado.', 'error')
                raise
        return self.discover_osm()

    def discover_google_places(self) -> list[dict[str, Any]]:
        query = ' '.join(str(self.params.get(k) or '') for k in ['niche', 'neighborhood', 'city', 'region']).strip()
        desired = min(int(self.params['desired_count']), 50)
        results = []
        page_token = None
        fields = ','.join([
            'places.id', 'places.displayName', 'places.formattedAddress', 'places.location',
            'places.nationalPhoneNumber', 'places.internationalPhoneNumber', 'places.websiteUri',
            'places.googleMapsUri', 'places.rating', 'places.userRatingCount', 'places.businessStatus',
            'places.types', 'places.primaryTypeDisplayName', 'places.regularOpeningHours',
            'places.reviews', 'nextPageToken',
        ])
        for _ in range(4):
            self.check_cancel()
            body = {'textQuery': query, 'languageCode': 'pt-BR', 'regionCode': 'BR', 'pageSize': min(20, desired)}
            if page_token:
                body['pageToken'] = page_token
            response = requests.post('https://places.googleapis.com/v1/places:searchText', headers={
                'X-Goog-Api-Key': self.google_key, 'X-Goog-FieldMask': fields, 'Content-Type': 'application/json',
            }, json=body, timeout=25)
            if response.status_code != 200:
                raise ResearchError(f'Google Places HTTP {response.status_code}: {response.text[:240]}')
            data = response.json()
            for place in data.get('places', []):
                display = place.get('displayName') or {}
                opening = place.get('regularOpeningHours') or {}
                reviews = []
                for review in place.get('reviews', [])[:5]:
                    reviews.append({
                        'author': (review.get('authorAttribution') or {}).get('displayName'),
                        'rating_label': f"{review.get('rating')} estrelas" if review.get('rating') is not None else None,
                        'date_display': review.get('relativePublishTimeDescription'),
                        'text': (review.get('text') or {}).get('text') if isinstance(review.get('text'), dict) else review.get('text'),
                        'review_id': review.get('name'),
                    })
                candidate = {
                    'source': 'google_places', 'source_id': place.get('id'),
                    'name': display.get('text'), 'address': place.get('formattedAddress'),
                    'neighborhood': self.params.get('neighborhood') if self.params.get('neighborhood') and ascii_text(self.params.get('neighborhood')) in ascii_text(place.get('formattedAddress')) else None,
                    'city': self.params.get('city') if self.params.get('city') and ascii_text(self.params.get('city')) in ascii_text(place.get('formattedAddress')) else None,
                    'region': self.params.get('region'),
                    'phone': place.get('internationalPhoneNumber') or place.get('nationalPhoneNumber'),
                    'website': place.get('websiteUri'), 'maps_url': place.get('googleMapsUri'),
                    'maps_status': 'VERIFICADO' if place.get('googleMapsUri') else 'NÃO VERIFICADO',
                    'rating': place.get('rating'), 'review_count': place.get('userRatingCount'), 'reviews': reviews,
                    'business_status': place.get('businessStatus'), 'category': (place.get('primaryTypeDisplayName') or {}).get('text'),
                    'types': place.get('types') or [], 'hours': '; '.join(opening.get('weekdayDescriptions') or []) or None,
                    'source_url': place.get('googleMapsUri'),
                }
                if not self._location_relevant(candidate):
                    continue
                results.append(candidate)
                if len(results) >= desired:
                    return results
            page_token = data.get('nextPageToken')
            if not page_token:
                break
            time.sleep(2)
        return results

    def _osm_wait(self):
        with OSM_RATE_LOCK:
            elapsed = time.monotonic() - OSM_LAST_CALL[0]
            if elapsed < 1.1:
                time.sleep(1.1 - elapsed)
            OSM_LAST_CALL[0] = time.monotonic()

    def _osm_get(self, url: str, **kwargs) -> requests.Response:
        self._osm_wait()
        headers = {'User-Agent': USER_AGENT, 'Accept-Language': 'pt-BR,pt;q=0.9'}
        if os.environ.get('MOON_OSM_CONTACT_EMAIL'):
            headers['From'] = os.environ['MOON_OSM_CONTACT_EMAIL']
        return requests.get(url, headers=headers, timeout=30, **kwargs)

    def discover_osm(self) -> list[dict[str, Any]]:
        query = ', '.join(x for x in [self.params.get('niche'), self.params.get('neighborhood'), self.params.get('city'), self.params.get('region'), 'Brasil'] if x)
        desired = min(int(self.params['desired_count']), 50)
        params = {'format': 'jsonv2', 'q': query, 'limit': min(50, max(desired * 2, 10)), 'addressdetails': 1, 'extratags': 1, 'namedetails': 1}
        response = self._osm_get('https://nominatim.openstreetmap.org/search', params=params)
        if response.status_code != 200:
            raise ResearchError(f'Nominatim HTTP {response.status_code}: {response.text[:200]}')
        items = response.json()
        results = [self._candidate_from_nominatim(x) for x in items if x.get('name') or x.get('display_name')]
        results = [x for x in results if x['name'] and self._location_relevant(x)]
        if len(results) < desired:
            try:
                results.extend(x for x in self._discover_overpass(desired - len(results), query) if self._location_relevant(x))
            except Exception as exc:
                self.event(f'Overpass não completou a busca complementar: {str(exc)[:180]}', 'warning')
        unique = []
        seen = set()
        for item in results:
            key = item.get('source_id') or (ascii_text(item.get('name')), ascii_text(item.get('address')))
            if key not in seen:
                seen.add(key)
                unique.append(item)
        return unique

    def _location_relevant(self, candidate: dict[str, Any]) -> bool:
        """Reject explicit geographic mismatches instead of filling quantity with nearby cities."""
        requested_city = ascii_text(self.params.get('city'))
        actual_city = ascii_text(candidate.get('city'))
        address = ascii_text(candidate.get('address'))
        if requested_city:
            if actual_city and requested_city not in actual_city and actual_city not in requested_city:
                return False
            if not actual_city and requested_city not in address:
                return False
        requested_local = self.params.get('neighborhood')
        if not requested_local:
            region = str(self.params.get('region') or '')
            if region and not re.match(r'(?i)^(zona|regiao|região|grande|centro)\b', region.strip()):
                requested_local = region
        if requested_local:
            wanted = ascii_text(requested_local)
            actual = ascii_text(candidate.get('neighborhood'))
            if actual and wanted not in actual and actual not in wanted and wanted not in address:
                return False
            if not actual and wanted not in address:
                return False
        return True

    def _candidate_from_nominatim(self, item: dict[str, Any]) -> dict[str, Any]:
        tags = item.get('extratags') or {}
        address = item.get('address') or {}
        osm_type = item.get('osm_type') or item.get('type')
        osm_id = item.get('osm_id')
        osm_url = f'https://www.openstreetmap.org/{osm_type}/{osm_id}' if osm_type and osm_id else None
        name = item.get('name') or (item.get('namedetails') or {}).get('name') or str(item.get('display_name') or '').split(',')[0]
        return {
            'source': 'openstreetmap', 'source_id': f'{osm_type}/{osm_id}', 'name': name,
            'address': item.get('display_name'), 'neighborhood': address.get('suburb') or address.get('neighbourhood'),
            'city': address.get('city') or address.get('town') or address.get('municipality'),
            'region': self.params.get('region'), 'phone': tags.get('contact:phone') or tags.get('phone'),
            'whatsapp': tags.get('contact:whatsapp') or tags.get('whatsapp'), 'website': tags.get('contact:website') or tags.get('website'),
            'instagram': tags.get('contact:instagram') or tags.get('instagram'), 'facebook': tags.get('contact:facebook') or tags.get('facebook'),
            'hours': tags.get('opening_hours'), 'description': tags.get('description'),
            'category': tags.get('shop') or tags.get('amenity') or tags.get('craft') or item.get('category'),
            'tags': tags, 'source_url': osm_url, 'maps_url': None, 'maps_status': 'NÃO VERIFICADO',
            'osm_url': osm_url, 'rating': None, 'review_count': None, 'reviews': [],
        }

    def _discover_overpass(self, desired: int, query: str) -> list[dict[str, Any]]:
        if desired <= 0:
            return []
        geo_query = ', '.join(x for x in [self.params.get('neighborhood'), self.params.get('city'), self.params.get('region'), 'Brasil'] if x)
        response = self._osm_get('https://nominatim.openstreetmap.org/search', params={'format': 'jsonv2', 'q': geo_query, 'limit': 1})
        if response.status_code != 200 or not response.json():
            return []
        bbox = response.json()[0].get('boundingbox')
        if not bbox or len(bbox) != 4:
            return []
        # Overpass expects south,west,north,east; Nominatim returns south,north,west,east.
        box = f'{bbox[0]},{bbox[2]},{bbox[1]},{bbox[3]}'
        niche = ascii_text(self.params.get('niche'))
        keyword = re.escape(self.params.get('niche') or '')
        clauses = [f'nwr["name"~"{keyword}",i]({box});']
        if any(x in niche for x in ['hamburg', 'burger']):
            clauses.append(f'nwr["cuisine"~"burger|hamburger",i]({box});')
        if 'restaurante' in niche:
            clauses.append(f'nwr["amenity"="restaurant"]({box});')
        if any(x in niche for x in ['confeitar', 'doce', 'padaria']):
            clauses.extend([f'nwr["shop"="bakery"]({box});', f'nwr["shop"="pastry"]({box});'])
        if any(x in niche for x in ['barbear', 'cabeleir', 'salao']):
            clauses.append(f'nwr["shop"="hairdresser"]({box});')
        if 'veterin' in niche:
            clauses.append(f'nwr["amenity"="veterinary"]({box});')
        if any(x in niche for x in ['pet', 'cachorr', 'creche', 'hotel']):
            clauses.extend([f'nwr["shop"="pet"]({box});', f'nwr["amenity"="animal_boarding"]({box});'])
        if 'academia' in niche:
            clauses.append(f'nwr["leisure"="fitness_centre"]({box});')
        if 'clinica' in niche:
            clauses.append(f'nwr["amenity"="clinic"]({box});')
        if any(x in niche for x in ['estetica', 'beleza']):
            clauses.append(f'nwr["shop"="beauty"]({box});')
        if 'massagem' in niche:
            clauses.append(f'nwr["shop"="massage"]({box});')
        limit = min(max(desired * 3, 20), 80)
        overpass_query = '[out:json][timeout:25];(' + ''.join(dict.fromkeys(clauses)) + f');out center tags {limit};'
        response = self._osm_get('https://overpass-api.de/api/interpreter', params={'data': overpass_query})
        if response.status_code != 200:
            raise ResearchError(f'Overpass HTTP {response.status_code}')
        results = []
        for element in response.json().get('elements', []):
            tags = element.get('tags') or {}
            if not tags.get('name'):
                continue
            osm_type = element.get('type')
            osm_id = element.get('id')
            fake_item = {
                'osm_type': osm_type, 'osm_id': osm_id, 'name': tags.get('name'),
                'display_name': ', '.join(filter(None, [tags.get('name'), tags.get('addr:street'), tags.get('addr:housenumber'), tags.get('addr:suburb'), tags.get('addr:city')])) or tags.get('name'),
                'address': {'suburb': tags.get('addr:suburb'), 'city': tags.get('addr:city')}, 'extratags': tags,
                'category': tags.get('shop') or tags.get('amenity'),
            }
            results.append(self._candidate_from_nominatim(fake_item))
        return results[:desired]

    def _web_search(self, name: str) -> list[dict[str, str]]:
        if not (self.cse_key and self.cse_cx):
            return []
        query = f'"{name}" "{self.params.get("city") or ""}" {self.params.get("niche") or ""}'
        response = requests.get('https://www.googleapis.com/customsearch/v1', params={
            'key': self.cse_key, 'cx': self.cse_cx, 'q': query, 'num': 5, 'hl': 'pt-BR',
        }, timeout=20)
        if response.status_code != 200:
            self.event(f'Google Custom Search retornou HTTP {response.status_code} para {name}.', 'warning')
            return []
        results = []
        for item in response.json().get('items', []):
            text = (item.get('title') or '') + ' ' + (item.get('snippet') or '')
            if _name_matches(name, text):
                results.append({'url': item.get('link'), 'title': item.get('title'), 'snippet': item.get('snippet')})
        return results

    def process_candidate(self, candidate: dict[str, Any]) -> dict[str, Any] | None:
        self.check_cancel()
        name = (candidate.get('name') or '').strip()
        if not name:
            return None
        segment = self.params.get('niche')
        sources = [{'tipo': candidate.get('source'), 'url': candidate.get('source_url'), 'data': utcnow(), 'resultado': 'Empresa retornada pela fonte de descoberta.'}]
        other_links = []
        if candidate.get('osm_url'):
            other_links.append({'plataforma': 'OpenStreetMap', 'url': candidate['osm_url'], 'status': 'VERIFICADO', 'fonte': 'Registro retornado pelo OpenStreetMap', 'observacao': 'Fonte de descoberta; não é uma ficha do Google Maps.'})
        lead = {
            'name': name, 'segment': segment, 'description': candidate.get('description'),
            'neighborhood': candidate.get('neighborhood'), 'city': candidate.get('city'), 'region': candidate.get('region'),
            'address': candidate.get('address'), 'image_url': None,
            'maps_url': candidate.get('maps_url'), 'maps_status': candidate.get('maps_status') or 'NÃO VERIFICADO',
            'rating': candidate.get('rating'), 'review_count': candidate.get('review_count'), 'reviews': candidate.get('reviews') or [],
            'hours': candidate.get('hours'), 'services': [candidate['category']] if candidate.get('category') else [],
            'products': [], 'prices': [], 'order_methods': [], 'differentials': [],
            'strengths': [], 'opportunities': [], 'other_links': other_links, 'sources': sources,
            'unconfirmed': [], 'problem_links': [], 'verification_notes': [],
            'research_date': utcnow(), 'raw': {'candidate': {k: v for k, v in candidate.items() if k != 'reviews'}},
        }
        if candidate.get('business_status') and candidate['business_status'] != 'OPERATIONAL':
            lead['qualification_status'] = 'NÃO QUALIFICADO'
            lead['verification_notes'].append(f'Status operacional informado: {candidate["business_status"]}.')

        website = candidate.get('website')
        instagram_candidate = candidate.get('instagram')
        instagram_identity_from_source = bool(candidate.get('instagram'))
        website_content = ''
        if website and 'instagram.com' in website:
            instagram_candidate = instagram_candidate or website
            instagram_identity_from_source = True
            website = None
        if website and any(x in website for x in ['wa.me/', 'wa.link/', 'whatsapp.com/']):
            candidate['whatsapp'] = candidate.get('whatsapp') or website
            website = None
        if website:
            verification = self.verifier.verify(website, name, 'Website informado pela fonte empresarial', identity_from_source=True)
            lead['site_url'] = website
            lead['site_status'] = verification['status']
            lead['verification_notes'].append(f"Site: {verification['observacao']}")
            sources.append({'tipo': 'Site oficial informado', 'url': website, 'data': utcnow(), 'resultado': verification['observacao']})
            website_content = verification.pop('conteudo', '')
            if website_content:
                for link in self._extract_social_links(website, website_content):
                    if link['plataforma'] == 'Instagram' and not instagram_candidate:
                        instagram_candidate = link['url']
                        instagram_identity_from_source = True
                    else:
                        other_links.append(link)
        else:
            lead['site_url'] = None
            lead['site_status'] = 'NÃO VERIFICADO'
            lead['unconfirmed'].append('site oficial')

        web_results = self._web_search(name)
        for result in web_results:
            url = result.get('url')
            if not url:
                continue
            if 'instagram.com' in url and not instagram_candidate:
                instagram_candidate = url
            elif not website and not any(domain in url for domain in ['facebook.com', 'instagram.com', 'tiktok.com', 'google.com']):
                # CSE suggestions remain unverified until opened and matched.
                verification = self.verifier.verify(url, name, 'Google Custom Search; título/trecho compatíveis', identity_from_source=False)
                if verification['status'] == 'VERIFICADO' and not lead.get('site_url'):
                    lead['site_url'] = url
                    lead['site_status'] = 'VERIFICADO'
                    website_content = verification.get('conteudo') or ''
                else:
                    other_links.append({'plataforma': platform_for_url(url), 'url': url, 'status': verification['status'], 'fonte': 'Google Custom Search', 'observacao': verification['observacao']})

        instagram_url = canonical_instagram(instagram_candidate)
        if instagram_url:
            verification = self.verifier.verify(instagram_url, name, 'Perfil informado por fonte empresarial, site oficial ou busca configurada', identity_from_source=instagram_identity_from_source)
            lead['instagram_url'] = instagram_url
            lead['instagram_status'] = verification['status']
            lead['followers'] = _parse_followers(verification.get('conteudo') or '')
            lead['last_post_date'] = None
            lead['post_frequency'] = None
            lead['verification_notes'].append('Instagram: publicação mais recente não foi preenchida porque a fonte não a expôs de forma confiável.')
            sources.append({'tipo': 'Instagram', 'url': instagram_url, 'data': utcnow(), 'resultado': verification['observacao']})
        else:
            lead.update({'instagram_url': None, 'instagram_status': 'NÃO VERIFICADO', 'followers': None, 'last_post_date': None, 'post_frequency': None})
            if instagram_candidate:
                lead['verification_notes'].append('Um endereço de Instagram foi encontrado, mas não era um perfil canônico válido e foi descartado.')
            else:
                lead['unconfirmed'].append('Instagram oficial')

        phone_input = candidate.get('whatsapp') or candidate.get('phone')
        number, wa_url = normalize_br_phone(phone_input)
        if number and wa_url:
            lead['whatsapp_number'] = number
            lead['whatsapp_url'] = wa_url
            verification = self.verifier.verify(wa_url, name, 'Número associado à empresa pela fonte de descoberta', identity_from_source=True)
            content = (verification.get('conteudo') or '').lower()
            invalid = 'phone number shared via url is invalid' in content or 'número de telefone compartilhado' in content and 'inválido' in content
            if invalid:
                lead['whatsapp_status'] = 'INCONSISTENTE'
                lead['verification_notes'].append('WhatsApp: a página indicou número inválido.')
            else:
                lead['whatsapp_status'] = verification['status']
                lead['verification_notes'].append('WhatsApp: a titularidade se apoia na associação empresarial do número; HTTP 200 não foi usado isoladamente.')
            sources.append({'tipo': 'WhatsApp', 'url': wa_url, 'data': utcnow(), 'resultado': lead['verification_notes'][-1]})
        else:
            lead.update({'whatsapp_number': None, 'whatsapp_url': None, 'whatsapp_status': 'NÃO VERIFICADO'})
            lead['unconfirmed'].append('WhatsApp')

        # Validate additional explicitly supplied links; never create handles from names.
        explicit_links = []
        for key in ['facebook', 'tiktok', 'ifood', 'menu', 'booking']:
            if candidate.get(key):
                explicit_links.append(candidate[key])
        pending_links = [x['url'] for x in other_links if x.get('url') and not x.get('status')]
        other_links = [x for x in other_links if x.get('status')]
        explicit_links.extend(pending_links)
        seen_links = {x.get('url') for x in other_links}
        for url in explicit_links[:8]:
            self.check_cancel()
            if not url or url in seen_links or url == lead.get('site_url'):
                continue
            verification = self.verifier.verify(url, name, 'Link explícito encontrado na fonte', identity_from_source=True)
            other_links.append({'plataforma': platform_for_url(url), 'url': url, 'status': verification['status'], 'fonte': 'Fonte empresarial ou página oficial', 'observacao': verification['observacao']})
            seen_links.add(url)
        lead['other_links'] = other_links

        lead['qualification_status'] = self._qualify(lead, candidate)
        self._apply_configurable_criteria(lead)
        lead['confidence'] = self._confidence(lead, candidate)
        lead['opportunity_level'] = self._opportunity_level(lead)
        for platform in ['instagram', 'whatsapp', 'site', 'maps']:
            status = lead.get(f'{platform}_status')
            if status in {'INDISPONÍVEL', 'INCONSISTENTE', 'NÃO VERIFICADO'}:
                lead['problem_links'].append({'plataforma': platform, 'url': lead.get(f'{platform}_url'), 'status': status})
        analysis = build_analysis(lead)
        analysis, analysis_mode, ai_warning = enrich_analysis(lead, analysis)
        lead['verification_notes'].append('Análise comercial enriquecida por IA; links e status permaneceram fora da IA.' if analysis_mode == 'ai' else 'Análise comercial determinística baseada em regras e evidências.')
        if ai_warning:
            lead['verification_notes'].append(ai_warning)
        lead.update(analysis)
        lead['briefing'] = build_briefing(lead)
        return lead

    def _extract_social_links(self, base_url: str, content: str) -> list[dict[str, Any]]:
        links = []
        for match in re.finditer(r'(?is)<a[^>]+href=["\'](.*?)["\']', content):
            url = urljoin(base_url, html.unescape(match.group(1)))
            host = (urlparse(url).hostname or '').lower()
            if any(domain in host for domain in ['instagram.com', 'facebook.com', 'tiktok.com', 'ifood.com', '99food', 'keeta']):
                platform = platform_for_url(url)
                if platform == 'Instagram':
                    canonical = canonical_instagram(url)
                    if canonical:
                        links.append({'plataforma': platform, 'url': canonical, 'status': None, 'fonte': 'Link encontrado no site oficial'})
                else:
                    links.append({'plataforma': platform, 'url': url, 'status': None, 'fonte': 'Link encontrado no site oficial'})
        return links[:8]

    def _qualify(self, lead: dict[str, Any], candidate: dict[str, Any]) -> str:
        if candidate.get('business_status') and candidate['business_status'] != 'OPERATIONAL':
            return 'NÃO QUALIFICADO'
        if lead.get('whatsapp_status') == 'INCONSISTENTE' or lead.get('site_status') == 'INCONSISTENTE':
            return 'NÃO QUALIFICADO'
        has_address = bool(lead.get('address'))
        has_contact = lead.get('whatsapp_status') == 'VERIFICADO' or lead.get('site_status') == 'VERIFICADO' or lead.get('instagram_status') == 'VERIFICADO'
        if lead.get('maps_status') == 'VERIFICADO' and has_address and has_contact:
            return 'VERIFICADO'
        if has_address and (has_contact or lead.get('other_links') or lead.get('reviews')):
            return 'PARCIALMENTE VERIFICADO'
        if has_address or has_contact:
            return 'PARCIALMENTE VERIFICADO'
        return 'NÃO QUALIFICADO'

    def _apply_configurable_criteria(self, lead: dict[str, Any]) -> None:
        criteria = self.params.get('criteria') or {}
        followers = lead.get('followers')
        min_f = self.params.get('min_followers')
        max_f = self.params.get('max_followers')
        if criteria.get('strict_followers') and followers is not None:
            outside = (min_f is not None and followers < min_f) or (max_f is not None and followers > max_f)
            if outside:
                lead['qualification_status'] = 'NÃO QUALIFICADO'
                lead['verification_notes'].append('Seguidores fora da faixa obrigatória configurada.')
        if criteria.get('only_without_site') and lead.get('site_url') and lead.get('site_status') == 'VERIFICADO':
            lead['qualification_status'] = 'NÃO QUALIFICADO'
            lead['verification_notes'].append('Possui site funcionando e o critério configurado foi “somente sem site”.')
        if criteria.get('require_recent_social'):
            if lead.get('last_post_date'):
                lead['verification_notes'].append('Atividade social identificada; a recência deve ser avaliada pela data registrada.')
            else:
                if lead['qualification_status'] == 'VERIFICADO':
                    lead['qualification_status'] = 'PARCIALMENTE VERIFICADO'
                lead['verification_notes'].append('Atividade recente era obrigatória, mas a fonte não expôs a data; o lead foi mantido como parcial, não tratado como inativo.')
        if criteria.get('notes'):
            lead['verification_notes'].append('Critério adicional registrado pelo usuário: ' + str(criteria['notes'])[:300])

    def _confidence(self, lead: dict[str, Any], candidate: dict[str, Any]) -> int:
        score = 40 if candidate.get('source') == 'google_places' else 25
        if lead.get('maps_status') == 'VERIFICADO':
            score += 20
        if lead.get('address'):
            score += 10
        if lead.get('whatsapp_status') == 'VERIFICADO':
            score += 15
        if lead.get('instagram_status') == 'VERIFICADO':
            score += 10
        if lead.get('site_status') == 'VERIFICADO':
            score += 5
        if lead.get('reviews'):
            score += 5
        return min(score, 100)

    def _opportunity_level(self, lead: dict[str, Any]) -> str:
        score = 0
        if not lead.get('site_url'):
            score += 25
        elif lead.get('site_status') in {'INDISPONÍVEL', 'INCONSISTENTE'}:
            score += 20
        if lead.get('last_post_date'):
            score += 15
        followers = lead.get('followers')
        min_f = self.params.get('min_followers')
        max_f = self.params.get('max_followers')
        if followers is not None and (min_f is None or followers >= min_f) and (max_f is None or followers <= max_f):
            score += 10
        if lead.get('whatsapp_status') == 'VERIFICADO':
            score += 15
        if lead.get('review_count'):
            score += 5
        if lead.get('maps_status') == 'VERIFICADO':
            score += 10
        if score >= 60:
            return 'Alto'
        if score >= 35:
            return 'Médio-alto'
        if score >= 20:
            return 'Médio'
        return 'Baixo'


def run_research(search_id: str, params: dict[str, Any], cancel_event: threading.Event):
    ResearchEngine(search_id, params, cancel_event).run()
