from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import threading
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / 'data'
DB_PATH = Path(os.environ.get('MOON_DB_PATH', DATA_DIR / 'moon_prospecting.db'))
_write_lock = threading.RLock()

SCHEMA = '''
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    password_salt TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    csrf_token TEXT NOT NULL,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS searches (
    id TEXT PRIMARY KEY,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    region TEXT,
    neighborhood TEXT,
    city TEXT,
    niche TEXT NOT NULL,
    desired_count INTEGER NOT NULL,
    min_followers INTEGER,
    max_followers INTEGER,
    criteria_json TEXT NOT NULL,
    provider TEXT NOT NULL,
    status TEXT NOT NULL,
    progress INTEGER NOT NULL DEFAULT 0,
    current_step TEXT,
    error TEXT,
    found_count INTEGER NOT NULL DEFAULT 0,
    verified_count INTEGER NOT NULL DEFAULT 0,
    partial_count INTEGER NOT NULL DEFAULT 0,
    notqualified_count INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS leads (
    id TEXT PRIMARY KEY,
    fingerprint TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    segment TEXT,
    description TEXT,
    neighborhood TEXT,
    city TEXT,
    region TEXT,
    address TEXT,
    image_url TEXT,
    instagram_url TEXT,
    instagram_status TEXT,
    followers INTEGER,
    last_post_date TEXT,
    post_frequency TEXT,
    whatsapp_number TEXT,
    whatsapp_url TEXT,
    whatsapp_status TEXT,
    site_url TEXT,
    site_status TEXT,
    maps_url TEXT,
    maps_status TEXT,
    other_links_json TEXT NOT NULL DEFAULT '[]',
    services_json TEXT NOT NULL DEFAULT '[]',
    products_json TEXT NOT NULL DEFAULT '[]',
    prices_json TEXT NOT NULL DEFAULT '[]',
    hours TEXT,
    order_methods_json TEXT NOT NULL DEFAULT '[]',
    differentials_json TEXT NOT NULL DEFAULT '[]',
    strengths_json TEXT NOT NULL DEFAULT '[]',
    opportunities_json TEXT NOT NULL DEFAULT '[]',
    commercial_analysis TEXT,
    approach_message TEXT,
    rating REAL,
    review_count INTEGER,
    reviews_json TEXT NOT NULL DEFAULT '[]',
    opportunity_level TEXT,
    confidence INTEGER NOT NULL DEFAULT 0,
    qualification_status TEXT NOT NULL,
    saved INTEGER NOT NULL DEFAULT 0,
    potential_client INTEGER NOT NULL DEFAULT 0,
    commercial_stage TEXT NOT NULL DEFAULT 'Novo lead',
    project_status TEXT NOT NULL DEFAULT 'NÃO INICIADO',
    notes TEXT NOT NULL DEFAULT '',
    logo TEXT,
    photos_json TEXT NOT NULL DEFAULT '[]',
    videos_json TEXT NOT NULL DEFAULT '[]',
    menu_catalog TEXT,
    visual_identity TEXT,
    materials_pending_json TEXT NOT NULL DEFAULT '[]',
    target_audience TEXT,
    visual_concept TEXT,
    palette_json TEXT NOT NULL DEFAULT '[]',
    sections_json TEXT NOT NULL DEFAULT '[]',
    features_json TEXT NOT NULL DEFAULT '[]',
    site_objective TEXT,
    sources_json TEXT NOT NULL DEFAULT '[]',
    unconfirmed_json TEXT NOT NULL DEFAULT '[]',
    problem_links_json TEXT NOT NULL DEFAULT '[]',
    verification_notes_json TEXT NOT NULL DEFAULT '[]',
    briefing_json TEXT,
    raw_json TEXT NOT NULL DEFAULT '{}',
    research_date TEXT,
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS search_leads (
    search_id TEXT NOT NULL REFERENCES searches(id) ON DELETE CASCADE,
    lead_id TEXT NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    PRIMARY KEY (search_id, lead_id)
);
CREATE TABLE IF NOT EXISTS search_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    search_id TEXT NOT NULL REFERENCES searches(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    level TEXT NOT NULL,
    message TEXT NOT NULL,
    progress INTEGER
);
CREATE TABLE IF NOT EXISTS lead_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lead_id TEXT NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    event_type TEXT NOT NULL,
    note TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value_json TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_leads_qualification ON leads(qualification_status);
CREATE INDEX IF NOT EXISTS idx_leads_saved ON leads(saved);
CREATE INDEX IF NOT EXISTS idx_leads_segment ON leads(segment);
CREATE INDEX IF NOT EXISTS idx_search_leads_search ON search_leads(search_id);
'''

JSON_COLUMNS = {
    'other_links', 'services', 'products', 'prices', 'order_methods',
    'differentials', 'strengths', 'opportunities', 'reviews', 'photos',
    'videos', 'materials_pending', 'palette', 'sections', 'features',
    'sources', 'unconfirmed', 'problem_links', 'verification_notes', 'raw',
}
BOOL_COLUMNS = {'saved', 'potential_client'}
CRM_COLUMNS = {'saved', 'potential_client', 'commercial_stage', 'project_status', 'notes', 'briefing'}
LEAD_FIELDS = [
    'id', 'fingerprint', 'name', 'segment', 'description', 'neighborhood',
    'city', 'region', 'address', 'image_url', 'instagram_url',
    'instagram_status', 'followers', 'last_post_date', 'post_frequency',
    'whatsapp_number', 'whatsapp_url', 'whatsapp_status', 'site_url',
    'site_status', 'maps_url', 'maps_status', 'other_links', 'services',
    'products', 'prices', 'hours', 'order_methods', 'differentials',
    'strengths', 'opportunities', 'commercial_analysis', 'approach_message',
    'rating', 'review_count', 'reviews', 'opportunity_level', 'confidence',
    'qualification_status', 'saved', 'potential_client', 'commercial_stage',
    'project_status', 'notes', 'logo', 'photos', 'videos', 'menu_catalog',
    'visual_identity', 'materials_pending', 'target_audience', 'visual_concept',
    'palette', 'sections', 'features', 'site_objective', 'sources',
    'unconfirmed', 'problem_links', 'verification_notes', 'briefing', 'raw',
    'research_date', 'first_seen', 'last_seen', 'created_at', 'updated_at',
]
DB_LEAD_COLUMNS = {field + '_json' if field in JSON_COLUMNS or field == 'briefing' else field for field in LEAD_FIELDS}


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def json_dump(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'))


def json_load(value: Any, default: Any) -> Any:
    if value is None or value == '':
        return default
    if isinstance(value, (list, dict)):
        return value
    try:
        return json.loads(value)
    except (TypeError, json.JSONDecodeError):
        return default


def connect() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    conn.execute('PRAGMA journal_mode = WAL')
    return conn


def init_db() -> None:
    with _write_lock, connect() as conn:
        conn.executescript(SCHEMA)
        defaults = {
            'default_min_followers': 900,
            'default_max_followers': 10000,
            'default_desired_count': 20,
            'reduced_motion': False,
            'results_per_page': 24,
        }
        for key, value in defaults.items():
            conn.execute('INSERT OR IGNORE INTO settings(key,value_json,updated_at) VALUES(?,?,?)', (key, json_dump(value), utcnow()))


def row_one(sql: str, args: tuple = ()) -> sqlite3.Row | None:
    with connect() as conn:
        return conn.execute(sql, args).fetchone()


def rows_all(sql: str, args: tuple = ()) -> list[sqlite3.Row]:
    with connect() as conn:
        return conn.execute(sql, args).fetchall()


def execute(sql: str, args: tuple = ()) -> int:
    with _write_lock, connect() as conn:
        cur = conn.execute(sql, args)
        return cur.rowcount


def fingerprint_for(lead: dict[str, Any]) -> str:
    if lead.get('fingerprint'):
        return str(lead['fingerprint'])
    phone = ''.join(c for c in str(lead.get('whatsapp_number') or '') if c.isdigit())
    base = '|'.join([
        (lead.get('name') or '').strip().lower(),
        (lead.get('address') or '').strip().lower(),
        phone,
        (lead.get('maps_url') or '').strip().lower(),
    ])
    return hashlib.sha256(base.encode('utf-8')).hexdigest()[:32]


def lead_from_row(row: sqlite3.Row | None) -> dict[str, Any] | None:
    if row is None:
        return None
    result = {}
    for key in row.keys():
        if key.endswith('_json'):
            field = key[:-5]
            default = {} if field == 'raw' else ([] if field != 'briefing' else None)
            result[field] = json_load(row[key], default)
        elif key in BOOL_COLUMNS:
            result[key] = bool(row[key])
        else:
            result[key] = row[key]
    return result


def _db_value(field: str, value: Any) -> Any:
    if field in JSON_COLUMNS or field == 'briefing':
        if field == 'briefing' and value is None:
            return None
        return json_dump(value if value is not None else ({} if field == 'raw' else []))
    if field in BOOL_COLUMNS:
        return int(bool(value))
    return value


def _lead_db_dict(lead: dict[str, Any]) -> dict[str, Any]:
    result = {}
    for field in LEAD_FIELDS:
        column = field + '_json' if field in JSON_COLUMNS or field == 'briefing' else field
        result[column] = _db_value(field, lead.get(field))
    return result


def upsert_lead(lead: dict[str, Any], search_id: str | None = None, preserve_briefing: bool = True) -> str:
    now = utcnow()
    item = dict(lead)
    item['fingerprint'] = fingerprint_for(item)
    existing_row = row_one('SELECT * FROM leads WHERE fingerprint = ?', (item['fingerprint'],))
    existing = lead_from_row(existing_row)
    if existing:
        item['id'] = existing['id']
        for field in CRM_COLUMNS:
            if field == 'briefing' and not preserve_briefing:
                continue
            item[field] = existing.get(field)
        item['created_at'] = existing['created_at']
        item['first_seen'] = existing.get('first_seen') or now
        item['last_seen'] = now
        item['updated_at'] = now
        # Never erase a useful existing value with an empty new result.
        for field in LEAD_FIELDS:
            if field in CRM_COLUMNS or field in {'id', 'fingerprint', 'created_at', 'first_seen', 'last_seen', 'updated_at'}:
                continue
            new_value = item.get(field)
            if new_value is None or new_value == '' or new_value == [] or new_value == {}:
                item[field] = existing.get(field)
    else:
        item['id'] = item.get('id') or str(uuid.uuid4())
        item['created_at'] = now
        item['updated_at'] = now
        item['first_seen'] = item.get('first_seen') or now
        item['last_seen'] = now
        item.setdefault('saved', False)
        item.setdefault('potential_client', False)
        item.setdefault('commercial_stage', 'Novo lead')
        item.setdefault('project_status', 'NÃO INICIADO')
        item.setdefault('confidence', 0)
        if item.get('confidence') is None:
            item['confidence'] = 0
        item.setdefault('notes', '')
    item['fingerprint'] = fingerprint_for(item)
    db_item = _lead_db_dict(item)
    columns = list(db_item)
    with _write_lock, connect() as conn:
        conn.execute(
            f"INSERT INTO leads ({','.join(columns)}) VALUES ({','.join('?' for _ in columns)}) "
            f"ON CONFLICT(id) DO UPDATE SET {','.join(c + '=excluded.' + c for c in columns if c != 'id')}",
            tuple(db_item[c] for c in columns),
        )
        if search_id:
            conn.execute('INSERT OR IGNORE INTO search_leads(search_id,lead_id,created_at) VALUES(?,?,?)', (search_id, item['id'], now))
        conn.execute('INSERT INTO lead_events(lead_id,created_at,event_type,note) VALUES(?,?,?,?)',
                     (item['id'], now, 'pesquisa', 'Empresa atualizada por pesquisa' if existing else 'Empresa adicionada por pesquisa'))
    return item['id']


def create_search(params: dict[str, Any], provider: str) -> str:
    search_id = str(uuid.uuid4())
    now = utcnow()
    with _write_lock, connect() as conn:
        conn.execute('''INSERT INTO searches(id,created_at,updated_at,region,neighborhood,city,niche,desired_count,min_followers,max_followers,criteria_json,provider,status,progress,current_step)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                     (search_id, now, now, params.get('region'), params.get('neighborhood'), params.get('city'), params['niche'],
                      int(params['desired_count']), params.get('min_followers'), params.get('max_followers'), json_dump(params.get('criteria') or {}),
                      provider, 'queued', 0, 'Pesquisa adicionada à fila'))
        conn.execute('INSERT INTO search_events(search_id,created_at,level,message,progress) VALUES(?,?,?,?,?)',
                     (search_id, now, 'info', 'Pesquisa criada; aguardando início do motor.', 0))
    return search_id


def update_search(search_id: str, **fields: Any) -> None:
    if not fields:
        return
    fields['updated_at'] = utcnow()
    columns = list(fields)
    execute(f"UPDATE searches SET {','.join(c + '=?' for c in columns)} WHERE id = ?", tuple(fields[c] for c in columns) + (search_id,))


def add_search_event(search_id: str, message: str, level: str = 'info', progress: int | None = None) -> None:
    with _write_lock, connect() as conn:
        conn.execute('INSERT INTO search_events(search_id,created_at,level,message,progress) VALUES(?,?,?,?,?)',
                     (search_id, utcnow(), level, message, progress))
    update_search(search_id, current_step=message, **({'progress': progress} if progress is not None else {}))


def recover_interrupted_searches() -> int:
    """Threads do not survive a process restart; make that limitation visible."""
    interrupted = rows_all("SELECT id FROM searches WHERE status IN ('queued','running','cancelling')")
    for row in interrupted:
        update_search(row['id'], status='cancelled', current_step='Interrompida por reinicialização do servidor; execute novamente.')
        add_search_event(row['id'], 'Pesquisa interrompida por reinicialização do servidor; nenhum resultado foi inventado.', 'warning')
    return len(interrupted)


def search_from_row(row: sqlite3.Row | None, include_events: bool = False) -> dict[str, Any] | None:
    if row is None:
        return None
    result = dict(row)
    result['criteria'] = json_load(result.pop('criteria_json', None), {})
    if include_events:
        result['events'] = [dict(x) for x in rows_all('SELECT id,created_at,level,message,progress FROM search_events WHERE search_id = ? ORDER BY id DESC LIMIT 100', (row['id'],))]
    return result


def get_search(search_id: str, include_events: bool = True) -> dict[str, Any] | None:
    return search_from_row(row_one('SELECT * FROM searches WHERE id = ?', (search_id,)), include_events)


def list_searches(limit: int = 50) -> list[dict[str, Any]]:
    return [search_from_row(x) for x in rows_all('SELECT * FROM searches ORDER BY created_at DESC LIMIT ?', (limit,))]


def get_lead(lead_id: str) -> dict[str, Any] | None:
    result = lead_from_row(row_one('SELECT * FROM leads WHERE id = ?', (lead_id,)))
    if result:
        result['events'] = [dict(x) for x in rows_all('SELECT id,created_at,event_type,note FROM lead_events WHERE lead_id = ? ORDER BY id DESC LIMIT 100', (lead_id,))]
    return result


def list_leads(filters: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    filters = filters or {}
    sql = 'SELECT DISTINCT l.* FROM leads l'
    args = []
    if filters.get('search_id'):
        sql += ' JOIN search_leads sl ON sl.lead_id = l.id'
    sql += ' WHERE 1=1'
    for field in ['qualification_status', 'segment', 'region', 'commercial_stage', 'project_status']:
        if filters.get(field):
            sql += f' AND l.{field} = ?'
            args.append(filters[field])
    if filters.get('search_id'):
        sql += ' AND sl.search_id = ?'
        args.append(filters['search_id'])
    for field in ['saved', 'potential_client']:
        if filters.get(field) is not None:
            sql += f' AND l.{field} = ?'
            args.append(int(bool(filters[field])))
    if filters.get('q'):
        sql += ' AND (LOWER(l.name) LIKE ? OR LOWER(l.address) LIKE ? OR LOWER(l.neighborhood) LIKE ?)'
        q = '%' + str(filters['q']).lower() + '%'
        args.extend([q, q, q])
    sql += ' ORDER BY l.saved DESC, l.confidence DESC, l.updated_at DESC'
    limit = min(max(int(filters.get('limit') or 500), 1), 1000)
    sql += ' LIMIT ?'
    args.append(limit)
    return [lead_from_row(x) for x in rows_all(sql, tuple(args))]


def update_lead(lead_id: str, fields: dict[str, Any], event_type: str = 'edicao', note: str = 'Informações editadas') -> dict[str, Any] | None:
    current = get_lead(lead_id)
    if not current:
        return None
    allowed = {
        'name', 'segment', 'description', 'neighborhood', 'city', 'region', 'address',
        'instagram_url', 'followers', 'last_post_date', 'post_frequency', 'whatsapp_number',
        'whatsapp_url', 'site_url', 'maps_url', 'hours', 'commercial_analysis',
        'approach_message', 'saved', 'potential_client', 'commercial_stage',
        'project_status', 'notes', 'site_objective', 'target_audience', 'visual_concept',
        'briefing', 'services', 'products', 'prices', 'order_methods', 'differentials',
        'materials_pending', 'sections', 'features',
    }
    changes = {k: v for k, v in fields.items() if k in allowed}
    if not changes:
        return current
    # Manual edits to a URL invalidate the old verification instead of inheriting it.
    for field, status_field in [('instagram_url', 'instagram_status'), ('whatsapp_url', 'whatsapp_status'), ('site_url', 'site_status'), ('maps_url', 'maps_status')]:
        if field in changes and changes[field] != current.get(field):
            changes[status_field] = 'NÃO VERIFICADO'
    changes['updated_at'] = utcnow()
    if 'briefing' in changes and changes['briefing'] is not None:
        changes['project_status'] = changes.get('project_status') or current.get('project_status')
    db_changes = {}
    for field, value in changes.items():
        if field in JSON_COLUMNS or field == 'briefing':
            db_changes[field + '_json'] = json_dump(value)
        elif field in BOOL_COLUMNS:
            db_changes[field] = int(bool(value))
        else:
            db_changes[field] = value
    columns = list(db_changes)
    with _write_lock, connect() as conn:
        conn.execute(f"UPDATE leads SET {','.join(c + '=?' for c in columns)} WHERE id = ?", tuple(db_changes[c] for c in columns) + (lead_id,))
        conn.execute('INSERT INTO lead_events(lead_id,created_at,event_type,note) VALUES(?,?,?,?)', (lead_id, utcnow(), event_type, note))
    return get_lead(lead_id)


def delete_lead(lead_id: str) -> bool:
    search_ids = [x['search_id'] for x in rows_all('SELECT search_id FROM search_leads WHERE lead_id = ?', (lead_id,))]
    deleted = execute('DELETE FROM leads WHERE id = ?', (lead_id,)) > 0
    if deleted:
        for search_id in search_ids:
            recalc_search_counts(search_id)
    return deleted


def add_lead_event(lead_id: str, event_type: str, note: str) -> None:
    execute('INSERT INTO lead_events(lead_id,created_at,event_type,note) VALUES(?,?,?,?)', (lead_id, utcnow(), event_type, note))


def recalc_search_counts(search_id: str) -> None:
    rows = rows_all('''SELECT l.qualification_status, COUNT(*) AS total FROM search_leads sl
                       JOIN leads l ON l.id = sl.lead_id WHERE sl.search_id = ? GROUP BY l.qualification_status''', (search_id,))
    counts = {x['qualification_status']: x['total'] for x in rows}
    found = sum(counts.values())
    update_search(search_id, found_count=found,
                  verified_count=counts.get('VERIFICADO', 0),
                  partial_count=counts.get('PARCIALMENTE VERIFICADO', 0),
                  notqualified_count=counts.get('NÃO QUALIFICADO', 0))


def dashboard() -> dict[str, Any]:
    counts = {x['qualification_status']: x['total'] for x in rows_all('SELECT qualification_status, COUNT(*) AS total FROM leads GROUP BY qualification_status')}
    total = sum(counts.values())
    opportunities = row_one("SELECT COUNT(*) AS total FROM leads WHERE qualification_status != 'NÃO QUALIFICADO' AND (commercial_analysis IS NOT NULL AND commercial_analysis != '')")['total']
    projects = row_one("SELECT COUNT(*) AS total FROM leads WHERE project_status IN ('PROJETO PREPARADO','SITE GERADO')")['total']
    saved = row_one('SELECT COUNT(*) AS total FROM leads WHERE saved = 1')['total']
    potential = row_one('SELECT COUNT(*) AS total FROM leads WHERE potential_client = 1')['total']
    return {
        'total_companies': total,
        'verified': counts.get('VERIFICADO', 0),
        'partial': counts.get('PARCIALMENTE VERIFICADO', 0),
        'not_qualified': counts.get('NÃO QUALIFICADO', 0),
        'opportunities': opportunities,
        'projects_prepared': projects,
        'saved_leads': saved,
        'potential_clients': potential,
        'recent_searches': list_searches(6),
        'recent_activities': recent_activities(10),
    }


def recent_activities(limit: int = 12) -> list[dict[str, Any]]:
    activities = []
    for row in rows_all('''SELECT le.created_at, le.event_type AS type, le.note, l.name, l.id AS lead_id
                           FROM lead_events le JOIN leads l ON l.id = le.lead_id ORDER BY le.id DESC LIMIT ?''', (limit,)):
        activities.append(dict(row))
    for row in rows_all('SELECT created_at, level AS type, message AS note, id AS search_id FROM search_events ORDER BY id DESC LIMIT ?', (limit,)):
        item = dict(row)
        item['name'] = 'Motor de prospecção'
        activities.append(item)
    activities.sort(key=lambda x: x['created_at'], reverse=True)
    return activities[:limit]


def get_settings() -> dict[str, Any]:
    return {x['key']: json_load(x['value_json'], None) for x in rows_all('SELECT key,value_json FROM settings')}


def update_settings(values: dict[str, Any]) -> dict[str, Any]:
    allowed = {'default_min_followers', 'default_max_followers', 'default_desired_count', 'reduced_motion', 'results_per_page'}
    with _write_lock, connect() as conn:
        for key, value in values.items():
            if key in allowed:
                conn.execute('INSERT INTO settings(key,value_json,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json,updated_at=excluded.updated_at',
                             (key, json_dump(value), utcnow()))
    return get_settings()


def _password_hash(password: str, salt: bytes) -> str:
    return hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 310_000).hex()


def ensure_owner() -> tuple[str, str | None]:
    existing = row_one('SELECT id,email FROM users ORDER BY created_at LIMIT 1')
    if existing:
        return existing['email'], None
    email = os.environ.get('MOON_OWNER_EMAIL', 'owner@mooncreative.local').strip().lower()
    password = os.environ.get('MOON_OWNER_PASSWORD') or secrets.token_urlsafe(15)
    salt = secrets.token_bytes(16)
    now = utcnow()
    with _write_lock, connect() as conn:
        conn.execute('INSERT INTO users(id,email,password_hash,password_salt,created_at,updated_at) VALUES(?,?,?,?,?,?)',
                     (str(uuid.uuid4()), email, _password_hash(password, salt), salt.hex(), now, now))
    access_file = DATA_DIR / 'OWNER_ACCESS.txt'
    access_file.write_text(f'Moon Creative — acesso inicial\nE-mail: {email}\nSenha: {password}\nTroque esta senha após o primeiro acesso.\n', encoding='utf-8')
    try:
        access_file.chmod(0o600)
    except OSError:
        pass
    return email, password


def verify_login(email: str, password: str) -> sqlite3.Row | None:
    user = row_one('SELECT * FROM users WHERE email = ?', (email.strip().lower(),))
    if not user:
        return None
    expected = _password_hash(password, bytes.fromhex(user['password_salt']))
    if not hmac.compare_digest(expected, user['password_hash']):
        return None
    return user


def change_password(user_id: str, current_password: str, new_password: str) -> bool:
    user = row_one('SELECT * FROM users WHERE id = ?', (user_id,))
    if not user:
        return False
    expected = _password_hash(current_password, bytes.fromhex(user['password_salt']))
    if not hmac.compare_digest(expected, user['password_hash']):
        return False
    salt = secrets.token_bytes(16)
    execute('UPDATE users SET password_hash=?,password_salt=?,updated_at=? WHERE id=?', (_password_hash(new_password, salt), salt.hex(), utcnow(), user_id))
    execute('DELETE FROM sessions WHERE user_id = ?', (user_id,))
    return True


def create_session(user_id: str) -> tuple[str, str, str]:
    token = secrets.token_urlsafe(32)
    csrf = secrets.token_urlsafe(24)
    now = datetime.now(timezone.utc)
    expires = now + timedelta(hours=12)
    with _write_lock, connect() as conn:
        conn.execute('INSERT INTO sessions(token_hash,user_id,csrf_token,created_at,expires_at) VALUES(?,?,?,?,?)',
                     (hashlib.sha256(token.encode()).hexdigest(), user_id, csrf, now.isoformat(), expires.isoformat()))
    return token, csrf, expires.isoformat()


def get_session(token: str | None) -> dict[str, Any] | None:
    if not token:
        return None
    row = row_one('''SELECT s.*, u.email, u.id AS owner_id FROM sessions s JOIN users u ON u.id = s.user_id
                     WHERE s.token_hash = ? AND s.expires_at > ?''', (hashlib.sha256(token.encode()).hexdigest(), utcnow()))
    return dict(row) if row else None


def delete_session(token: str | None) -> None:
    if token:
        execute('DELETE FROM sessions WHERE token_hash = ?', (hashlib.sha256(token.encode()).hexdigest(),))
