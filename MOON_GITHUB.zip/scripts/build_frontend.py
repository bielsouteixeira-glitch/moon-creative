"""Build the dependency-free Netlify frontend.
Only API_BASE_URL is public configuration; no secret is read or emitted here.
"""
from pathlib import Path
import json
import os
import shutil

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'frontend'
OUTPUT = ROOT / 'dist'
if OUTPUT.exists():
    shutil.rmtree(OUTPUT)
shutil.copytree(SOURCE, OUTPUT)
api_base = os.environ.get('API_BASE_URL', '').strip().rstrip('/')
if api_base and not api_base.startswith(('https://', 'http://')):
    raise SystemExit('API_BASE_URL deve começar com https:// (ou http:// somente em desenvolvimento).')
(OUTPUT / 'runtime-config.js').write_text('window.MOON_API_BASE = ' + json.dumps(api_base) + ';\n', encoding='utf-8')
print(f'Frontend publicável gerado em {OUTPUT} · API_BASE_URL={"mesma origem" if not api_base else api_base}')
