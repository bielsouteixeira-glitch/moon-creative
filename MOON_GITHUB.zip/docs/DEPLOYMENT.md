# Publicação — Netlify + backend persistente

## 1. Backend

Hospede `backend/server.py` em um serviço Python com disco persistente (por exemplo, uma VM, Render com disco, Railway com volume ou container equivalente). O servidor usa apenas a biblioteca padrão e `requests`.

Variáveis mínimas recomendadas:

```dotenv
PORT=8000
MOON_OWNER_EMAIL=seu-email-privado@example.com
MOON_OWNER_PASSWORD=uma-senha-longa-aleatoria
MOON_DB_PATH=/var/lib/moon/moon_prospecting.db
ALLOWED_ORIGINS=https://seu-projeto.netlify.app
COOKIE_SECURE=1
COOKIE_SAMESITE=None
MOON_OSM_CONTACT_EMAIL=seu-email-operacional@example.com
```

Crie o diretório de `MOON_DB_PATH` com permissão de escrita e faça backup do arquivo SQLite. Não use um filesystem efêmero para o banco. O primeiro start cria o proprietário; depois disso, alterar `MOON_OWNER_PASSWORD` não troca a senha existente — use Configurações na interface.

O comando de execução é:

```bash
python3 backend/server.py
```

Para container, o `Dockerfile` incluído expõe a porta 8000. Monte um volume em `/app/data` ou aponte `MOON_DB_PATH` para outro volume persistente. O seed é importado apenas em um banco vazio.

## 2. Netlify

No site Netlify, defina somente a configuração pública:

```dotenv
API_BASE_URL=https://sua-api.example.com
```

O build configurado em `netlify.toml` executa:

```bash
python3 scripts/build_frontend.py
```

e publica `dist/`. O script copia os arquivos estáticos e grava `runtime-config.js` com a URL da API. Ele não lê nem emite nenhuma chave.

Para testar o build localmente:

```bash
API_BASE_URL=https://sua-api.example.com python3 scripts/build_frontend.py
```

## 3. CORS e cookies

Como o frontend e a API ficam em origens diferentes:

- `ALLOWED_ORIGINS` deve conter exatamente a origem HTTPS do site Netlify, sem barra final.
- O navegador usa `credentials: include`; o backend responde CORS somente para origens permitidas.
- Em produção cross-site, use `COOKIE_SECURE=1` e `COOKIE_SAMESITE=None`.
- Se frontend e API estiverem na mesma origem, pode-se usar `COOKIE_SAMESITE=Lax` e deixar `API_BASE_URL` vazio.
- Não use curinga `*` com credenciais.

## 4. Integrações opcionais

Configure estas variáveis **somente no serviço do backend**:

- `GOOGLE_PLACES_API_KEY`: habilita Places `searchText`, com campos de nome, endereço, telefone, site, Maps, avaliações e status quando retornados pela API.
- `GOOGLE_CSE_API_KEY` e `GOOGLE_CSE_CX`: habilita busca web complementar. Os resultados ainda passam por abertura e verificação de identidade.
- `MOON_AI_API_KEY` e `MOON_AI_MODEL`: habilita enriquecimento de textos comerciais. Links, contatos, status e classificação não são enviados para alteração pelo modelo. Sem essas variáveis, a análise determinística continua funcionando.

A ausência de qualquer integração aparece em Configurações e no histórico; não é convertida em sucesso fictício.

## 5. Supabase

Não há conexão Supabase nesta entrega. O banco real ativo é SQLite. Portanto, não se deve declarar que RLS/Supabase está habilitado. Se uma migração futura para Supabase for feita, será necessário criar tabelas, políticas RLS, autenticação e testes específicos antes de ativá-la.

## 6. Verificação pós-publicação

1. Abrir `/api/health` no backend e confirmar `ok: true`.
2. Entrar pelo site Netlify e verificar que a sessão persiste após recarregar.
3. Confirmar que uma origem não autorizada não recebe CORS.
4. Executar uma pesquisa pequena e acompanhar eventos, progresso, conclusão ou erro.
5. Recarregar a página e abrir o histórico para confirmar persistência.
6. Testar salvar, editar, cancelar, copiar e baixar um JSON.
7. Conferir logs do servidor sem expor tokens ou cookies.

## 7. Operação responsável

- Respeite os termos e limites de Nominatim/Overpass e das APIs configuradas; personalize `MOON_OSM_USER_AGENT` se necessário.
- Não use a ferramenta para contornar login, CAPTCHA ou proteção de plataforma.
- Não trate 403/429 como inatividade ou inexistência.
- Revalide links e contatos antes de qualquer abordagem ou publicação.
- Nenhuma mensagem comercial é enviada automaticamente.
