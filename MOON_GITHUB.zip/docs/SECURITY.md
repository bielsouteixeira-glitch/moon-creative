# Segurança operacional

- Senhas com PBKDF2-HMAC-SHA256, salt aleatório e 310.000 iterações.
- Tokens de sessão armazenados somente como hash no SQLite; cookie `HttpOnly` com expiração de 12 horas.
- CSRF obrigatório em POST/PATCH/DELETE autenticados.
- Rate limit de login por IP e resposta genérica para credenciais inválidas.
- CORS por allowlist de origens, com credenciais somente para a origem configurada.
- Limite de payload de 2 MB, validação de campos de CRM e de esquema do briefing.
- URLs aceitas somente em HTTP/HTTPS, sem credenciais embutidas; resolução e bloqueio de IPs privados, loopback, link-local, multicast e reservados, inclusive após redirects.
- Resposta HTTP não é suficiente para provar identidade; o conteúdo precisa confirmar o nome, exceto o caminho documentado de associação empresarial do número de WhatsApp.
- A IA opcional não recebe autorização para modificar fatos, links ou status.
- Nenhum segredo é incluído no frontend, no seed, nos logs da interface ou nos briefings.

## Limites que exigem atenção em produção

- Use HTTPS e um proxy reverso com limite de requisições adicional.
- Restrinja o acesso ao volume SQLite e faça backups criptografados.
- O rate limit em memória é por instância; um ambiente multi-instância precisa de proteção compartilhada no proxy.
- Threads de pesquisa pertencem à instância que as iniciou. Em multi-instância, use uma fila persistente antes de escalar.
- Uma chamada de rede em curso pode atrasar a confirmação do cancelamento até seu timeout.
- Não exponha `data/OWNER_ACCESS.txt`, bancos, cookies ou arquivos `.env`.
