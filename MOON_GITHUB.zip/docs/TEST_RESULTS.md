# Resultados de validação

Data da execução: 02/11/2026.

## Executado e aprovado

- `PYTHONPATH=backend pytest -q tests` → **10 passed**.
- `node --check frontend/app.js` → sem erro de sintaxe.
- `MOON_OWNER_PASSWORD=... PYTHONPATH=backend python tests/api_smoke.py` → autenticação, sessão, CSRF, dashboard, 13 leads históricos, 62 avaliações, detalhe, briefing, filtros, validação de etapa, proteção contra mistura de empresas, mutações de CRM e restauração aprovados.
- `API_BASE_URL=https://api.mooncreative.example python3 scripts/build_frontend.py` → `dist/` gerado com cinco arquivos estáticos e URL pública de API isolada em `runtime-config.js`.
- Checagem estática de handlers → nenhum `data-action` apresentado sem handler; nenhum caminho local absoluto ou credencial no frontend.

## Pesquisa pública real

- Provedor disponível no ambiente: **OpenStreetMap/Nominatim/Overpass**.
- Uma pesquisa em Vila Maria, São Paulo, retornou uma empresa real e a persistiu como **PARCIALMENTE VERIFICADO**. Não foram atribuídos Instagram, avaliações do Google ou seguidores sem fonte.
- Uma pesquisa em Jardim Primavera terminou sem resultados após o filtro geográfico; nenhum lead fictício foi criado. Overpass apresentou timeout/erro em uma das tentativas e a limitação foi registrada.
- Um primeiro resultado geográfico divergente foi detectado durante o desenvolvimento, removido e o filtro foi corrigido antes da validação final.
- O cancelamento foi exercitado durante uma chamada de rede; a pesquisa terminou como `cancelled` após o timeout da chamada, sem resultados inventados. O artefato desse teste foi removido do histórico.

## Não executado / não configurado

- Não foi executado teste automatizado de navegador; o preview deve ser usado para a conferência visual e manual dos fluxos.
- Google Places, Google Custom Search e enriquecimento por IA não foram testados ao vivo porque não há credenciais configuradas no ambiente.
- Supabase não está conectado; o banco testado é SQLite.
- Nenhuma mensagem comercial foi enviada.
