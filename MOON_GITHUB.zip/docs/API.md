# API privada

Todas as rotas, exceto `/api/health`, `/api/auth/session` e `/api/auth/login`, exigem cookie de sessão. Mutações exigem o header `X-CSRF-Token` retornado no login/sessão.

| Método | Rota | Função |
|---|---|---|
| GET | `/api/health` | Saúde do serviço e provedor ativo |
| POST | `/api/auth/login` | Entrar e criar cookie/sessão |
| GET | `/api/auth/session` | Estado da sessão e CSRF |
| POST | `/api/auth/logout` | Encerrar sessão |
| POST | `/api/auth/password` | Trocar senha e invalidar sessões |
| GET/PATCH | `/api/settings` | Ler/salvar preferências não sensíveis |
| GET | `/api/dashboard` | Métricas e atividades calculadas do banco |
| GET | `/api/integrations` | Estado das integrações, sem segredos |
| GET/POST | `/api/research` | Listar ou iniciar pesquisas |
| GET | `/api/research/:id` | Progresso, contadores e eventos |
| POST | `/api/research/:id/cancel` | Solicitar cancelamento |
| GET | `/api/leads` | Filtros por pesquisa, status, nicho, região, texto, salvos e potenciais |
| GET/PATCH/DELETE | `/api/leads/:id` | Detalhar, editar ou excluir |
| POST | `/api/leads/:id/save` | Atualizar lead salvo |
| POST | `/api/leads/:id/potential` | Atualizar cliente potencial |
| POST | `/api/leads/:id/notes` | Acrescentar observação com timestamp |
| GET/POST | `/api/leads/:id/briefing` | Obter ou gerar briefing individual |

## Pesquisa — corpo mínimo

```json
{
  "city": "São Paulo",
  "neighborhood": "Vila Maria",
  "niche": "pet shop",
  "desired_count": 5,
  "min_followers": 900,
  "max_followers": 10000,
  "criteria": {
    "strict_followers": false,
    "require_recent_social": false,
    "only_without_site": false,
    "exclude_closed": true
  }
}
```

A resposta inicial é HTTP `202`. Consulte o ID até `completed`, `failed` ou `cancelled`. `found_count` representa empresas persistidas, não uma promessa de quantidade.

## Edição do briefing

`PATCH /api/leads/:id` aceita `briefing` como objeto JSON. O backend valida as seções obrigatórias e rejeita divergência entre `briefing.cliente.nome` e o nome do lead. O frontend também permite copiar e baixar sem alterar o objeto salvo.
