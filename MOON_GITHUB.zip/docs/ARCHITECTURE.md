# Arquitetura e integridade dos dados

## Fluxo

1. O proprietário autentica a sessão.
2. O frontend envia os parâmetros para `POST /api/research`.
3. O backend cria um registro de pesquisa e uma thread com `Event` de cancelamento.
4. O motor consulta Google Places ou OpenStreetMap, filtra correspondências geográficas explícitas e processa cada candidato.
5. Cada lead recebe fontes, status por link, confiança, classificação e análise baseada apenas nos dados coletados.
6. `store.upsert_lead` deduplica por fingerprint e preserva campos de CRM e briefing em novas pesquisas.
7. O frontend consulta o banco por API para dashboard, cards, histórico e CRM.
8. O briefing é gerado e validado individualmente; a edição manual exige que `cliente.nome` continue pertencendo ao lead.

## Banco

SQLite com foreign keys e tabelas `users`, `sessions`, `searches`, `leads`, `search_leads`, `search_events`, `lead_events` e `settings`. O caminho é configurável por `MOON_DB_PATH`.

Campos JSON são serializados no backend. Datas são ISO 8601. Dados ausentes permanecem `null` ou arrays vazios; a interface mostra `—` e pendências em vez de completar por dedução.

## Fontes e status

- `VERIFICADO`: evidência de identidade e acesso compatível, ou ficha específica de uma API oficial.
- `PARCIALMENTE VERIFICADO`: há evidência útil, mas faltam elementos para uma qualificação forte.
- `NÃO QUALIFICADO`: critério explícito de exclusão, inconsistência ou evidência insuficiente para prospecção.
- `NÃO VERIFICADO`: endereço ausente ou conteúdo que não confirmou a identidade.
- `INDISPONÍVEL`: acesso limitado/erro, incluindo 401/403/429; não implica inatividade.
- `INCONSISTENTE`: conflito de identidade ou contato.

OpenStreetMap é uma fonte de descoberta, não uma ficha do Google Maps. O sistema não transforma links homônimos em canais oficiais.

## IA

`backend/ai.py` é opcional e recebe um conjunto restrito de fatos para escrever textos comerciais. A resposta não pode alterar URLs, números, status, seguidores, avaliações ou classificação. Se a chamada falhar, o texto determinístico é mantido e a limitação entra nas observações.

## Frontend

SPA sem framework, com `app.js`, `styles.css` e `runtime-config.js`. A configuração pública contém apenas `window.MOON_API_BASE`. Todos os dados de negócio vêm da API; não há array de leads embutido no JavaScript.

A abertura usa CSS e pode ser pulada. O layout respeita `prefers-reduced-motion` e a preferência salva nas configurações.
