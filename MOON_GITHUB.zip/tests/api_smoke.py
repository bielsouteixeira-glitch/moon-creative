"""Authenticated API smoke test against an already running Moon backend.
Usage: MOON_BASE_URL=http://127.0.0.1:8000 MOON_OWNER_PASSWORD='...' python tests/api_smoke.py
The test restores every lead flag it changes.
"""
import json
import os
import sys

import requests

BASE = os.environ.get('MOON_BASE_URL', 'http://127.0.0.1:8000').rstrip('/')
EMAIL = os.environ.get('MOON_OWNER_EMAIL', 'owner@mooncreative.local')
PASSWORD = os.environ.get('MOON_OWNER_PASSWORD')
if not PASSWORD:
    raise SystemExit('Defina MOON_OWNER_PASSWORD para o smoke test.')

session = requests.Session()
response = session.get(BASE + '/api/health')
assert response.status_code == 200 and response.json()['ok']
assert session.get(BASE + '/api/leads').status_code == 401
response = session.post(BASE + '/api/auth/login', json={'email': EMAIL, 'password': PASSWORD})
assert response.status_code == 200, response.text
session.headers['X-CSRF-Token'] = response.json()['csrf']
assert session.get(BASE + '/api/auth/session').json()['authenticated'] is True
assert session.patch(BASE + '/api/settings', json={'default_desired_count': 20}, headers={'X-CSRF-Token': 'invalid'}).status_code == 403

dashboard = session.get(BASE + '/api/dashboard')
assert dashboard.status_code == 200
leads_response = session.get(BASE + '/api/leads', params={'limit': 1000})
assert leads_response.status_code == 200
leads = leads_response.json()['leads']
assert leads, 'Nenhum lead disponível para o smoke test'
seed_search = next((x for x in session.get(BASE + '/api/research').json()['searches'] if x['provider'] == 'historical_import'), None)
assert seed_search is not None
assert session.post(BASE + '/api/research/' + seed_search['id'] + '/cancel', json={}).status_code == 409
historical = session.get(BASE + '/api/leads', params={'search_id': seed_search['id'], 'limit': 100}).json()['leads']
assert len(historical) == 13
assert sum(len(x['reviews']) for x in historical) == 62
lead = next(x for x in historical if x.get('briefing'))
lead_id = lead['id']
detail = session.get(BASE + '/api/leads/' + lead_id)
assert detail.status_code == 200
briefing = session.get(BASE + '/api/leads/' + lead_id + '/briefing').json()['briefing']
for key in ['projeto', 'cliente', 'contatos_e_links', 'presenca_digital', 'informacoes_do_negocio', 'materiais_visuais', 'planejamento_do_site', 'verificacao']:
    assert key in briefing
assert briefing['cliente']['nome'] == lead['name']
assert session.patch(BASE + '/api/leads/' + lead_id, json={'commercial_stage': 'etapa inválida'}).status_code == 400
wrong = json.loads(json.dumps(briefing))
wrong['cliente']['nome'] = 'Empresa que não pertence a este lead'
assert session.patch(BASE + '/api/leads/' + lead_id, json={'briefing': wrong}).status_code == 400
assert session.post(BASE + '/api/leads/' + lead_id + '/notes', json={'note': ''}).status_code == 400

# Exercise mutations and restore their original values.
original = {'saved': lead['saved'], 'potential_client': lead['potential_client'], 'commercial_stage': lead['commercial_stage']}
try:
    changed = session.post(BASE + '/api/leads/' + lead_id + '/save', json={'saved': not original['saved']})
    assert changed.status_code == 200 and changed.json()['saved'] is (not original['saved'])
    changed = session.post(BASE + '/api/leads/' + lead_id + '/potential', json={'potential_client': not original['potential_client']})
    assert changed.status_code == 200 and changed.json()['potential_client'] is (not original['potential_client'])
    changed = session.patch(BASE + '/api/leads/' + lead_id, json={'commercial_stage': 'Interessado'})
    assert changed.status_code == 200 and changed.json()['commercial_stage'] == 'Interessado'
    changed = session.patch(BASE + '/api/leads/' + lead_id, json={'briefing': briefing})
    assert changed.status_code == 200 and changed.json()['briefing']['cliente']['nome'] == lead['name']
finally:
    session.post(BASE + '/api/leads/' + lead_id + '/save', json={'saved': original['saved']})
    session.post(BASE + '/api/leads/' + lead_id + '/potential', json={'potential_client': original['potential_client']})
    session.patch(BASE + '/api/leads/' + lead_id, json={'commercial_stage': original['commercial_stage']})

assert session.get(BASE + '/api/settings').status_code == 200
assert session.get(BASE + '/api/research').status_code == 200
print(json.dumps({'ok': True, 'base': BASE, 'dashboard': dashboard.json(), 'historical_leads': len(historical), 'historical_reviews': sum(len(x['reviews']) for x in historical)}, ensure_ascii=False))
