import threading

import store
from research import ResearchEngine, LinkVerifier


def test_cancel_after_empty_discovery_is_not_marked_completed(tmp_path, monkeypatch):
    monkeypatch.setattr(store, 'DB_PATH', tmp_path / 'cancel.db')
    store.init_db()
    search_id = store.create_search({'niche': 'pet shop', 'desired_count': 3}, 'test')
    cancel = threading.Event()
    engine = ResearchEngine(search_id, {'niche': 'pet shop', 'desired_count': 3}, cancel)
    def empty_discovery():
        cancel.set()
        return []
    monkeypatch.setattr(engine, 'discover', empty_discovery)
    engine.run()
    assert store.get_search(search_id)['status'] == 'cancelled'


def test_interrupted_search_is_recovered_as_cancelled(tmp_path, monkeypatch):
    monkeypatch.setattr(store, 'DB_PATH', tmp_path / 'recover.db')
    store.init_db()
    search_id = store.create_search({'niche': 'pet shop', 'desired_count': 1}, 'test')
    store.update_search(search_id, status='running')
    assert store.recover_interrupted_searches() == 1
    assert store.get_search(search_id)['status'] == 'cancelled'


def test_http_200_without_identity_is_not_verified(monkeypatch):
    verifier = LinkVerifier()
    monkeypatch.setattr(verifier, 'fetch', lambda url: {
        'http_status': 200, 'title': 'Página genérica', 'text': 'conteúdo sem relação',
        'content': '<title>Página genérica</title>', 'final_url': url, 'error': None,
    })
    result = verifier.verify('https://example.com', 'Negócio Muito Diferente', 'Website informado pela fonte empresarial', identity_from_source=True)
    assert result['status'] == 'NÃO VERIFICADO'
