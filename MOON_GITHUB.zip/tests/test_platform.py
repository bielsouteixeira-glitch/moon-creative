import json
import threading
from pathlib import Path

import pytest

import store
from briefing import build_briefing, validate_briefing
from research import ResearchEngine, LinkVerifier, canonical_instagram, normalize_br_phone, safe_url

ROOT = Path(__file__).resolve().parents[1]


def sample_lead(name='Empresa Teste'):
    return {
        'name': name, 'segment': 'pet shop', 'address': 'Rua Real, 123, Vila Maria, São Paulo',
        'city': 'São Paulo', 'neighborhood': 'Vila Maria', 'region': 'Zona Norte',
        'qualification_status': 'PARCIALMENTE VERIFICADO', 'maps_status': 'NÃO VERIFICADO',
        'instagram_status': 'NÃO VERIFICADO', 'whatsapp_status': 'NÃO VERIFICADO', 'site_status': 'NÃO VERIFICADO',
        'services': [], 'products': [], 'sources': [], 'reviews': [],
    }


@pytest.fixture
def isolated_store(tmp_path, monkeypatch):
    monkeypatch.setattr(store, 'DB_PATH', tmp_path / 'moon-test.db')
    store.init_db()
    return store


def test_seed_has_real_history_and_62_reviews():
    data = json.loads((ROOT / 'data' / 'seed_data.json').read_text(encoding='utf-8'))
    assert len(data['leads']) == 13
    assert sum(len(lead['reviews']) for lead in data['leads']) == 62
    assert sum(lead['briefing'] is not None for lead in data['leads']) == 7
    assert sum(lead['qualification_status'] == 'VERIFICADO' for lead in data['leads']) == 7
    assert sum(lead['qualification_status'] == 'NÃO QUALIFICADO' for lead in data['leads']) == 1
    assert all(lead['commercial_stage'] == 'Lead analisado' for lead in data['leads'])
    assert all(not lead['potential_client'] for lead in data['leads'])


def test_upsert_deduplicates_and_preserves_crm(isolated_store):
    search_id = isolated_store.create_search({'niche': 'pet shop', 'desired_count': 1}, 'test')
    lead = sample_lead()
    lead_id = isolated_store.upsert_lead(lead, search_id)
    isolated_store.update_lead(lead_id, {'saved': True, 'potential_client': True, 'commercial_stage': 'Interessado', 'notes': 'Preservar'})
    briefing = build_briefing(isolated_store.get_lead(lead_id))
    isolated_store.update_lead(lead_id, {'briefing': briefing})
    updated = sample_lead()
    updated['commercial_analysis'] = 'Nova análise'
    updated['saved'] = False
    updated['notes'] = ''
    same_id = isolated_store.upsert_lead(updated, search_id)
    assert same_id == lead_id
    saved = isolated_store.get_lead(lead_id)
    assert saved['saved'] is True
    assert saved['potential_client'] is True
    assert saved['commercial_stage'] == 'Interessado'
    assert saved['notes'] == 'Preservar'
    assert saved['briefing'] == briefing
    assert saved['commercial_analysis'] == 'Nova análise'
    assert len(isolated_store.list_leads()) == 1


def test_delete_recalculates_search_counts(isolated_store):
    search_id = isolated_store.create_search({'niche': 'pet shop', 'desired_count': 1}, 'test')
    lead_id = isolated_store.upsert_lead(sample_lead(), search_id)
    isolated_store.recalc_search_counts(search_id)
    assert isolated_store.get_search(search_id)['found_count'] == 1
    assert isolated_store.delete_lead(lead_id) is True
    assert isolated_store.get_search(search_id)['found_count'] == 0


def test_briefing_is_individual_and_does_not_invent_contact():
    lead = sample_lead('Empresa Sem Site')
    lead['research_date'] = '2026-11-02T00:00:00+00:00'
    briefing = build_briefing(lead)
    validate_briefing(briefing)
    assert briefing['cliente']['nome'] == 'Empresa Sem Site'
    assert briefing['contatos_e_links']['whatsapp']['numero'] is None
    assert briefing['contatos_e_links']['whatsapp']['url'] is None
    assert briefing['planejamento_do_site']['chamadas_para_acao'] == []
    assert {x['plataforma'] for x in briefing['verificacao']['links_com_problemas']} == {'instagram', 'whatsapp', 'site', 'maps'}
    with pytest.raises(ValueError):
        bad = dict(briefing)
        bad['cliente'] = dict(briefing['cliente'], nome='Outra Empresa')
        # The schema itself permits editing the name; the API performs the lead/name match.
        bad['projeto'] = {}
        validate_briefing(bad)


def test_canonical_and_ssrf_guards():
    assert canonical_instagram('@moon.creative') == 'https://www.instagram.com/moon.creative/'
    assert canonical_instagram('https://www.instagram.com/p/abc/') is None
    assert canonical_instagram('https://example.com/moon') is None
    assert normalize_br_phone('(11) 99999-8888') == ('+5511999998888', 'https://wa.me/5511999998888')
    assert normalize_br_phone('123') == (None, None)
    assert safe_url('http://127.0.0.1/admin') is None
    assert safe_url('http://localhost/admin') is None
    assert safe_url('javascript:alert(1)') is None


def test_location_filter_rejects_other_city_and_accepts_district_hierarchy():
    engine = ResearchEngine('test', {'city': 'São Paulo', 'neighborhood': 'Vila Maria', 'region': 'Zona Norte'}, threading.Event())
    other = {'city': 'Cotia', 'neighborhood': 'Aldeia de Carapicuíba', 'address': 'Rua X, Cotia, São Paulo, Brasil'}
    assert engine._location_relevant(other) is False
    district = {'city': 'São Paulo', 'neighborhood': 'Jardim Japão', 'address': 'Av. Conceição, Jardim Japão, Vila Maria, São Paulo, Brasil'}
    assert engine._location_relevant(district) is True
    wrong_local = {'city': 'São Paulo', 'neighborhood': 'Mooca', 'address': 'Rua X, Mooca, São Paulo, Brasil'}
    assert engine._location_relevant(wrong_local) is False


def test_frontend_is_offline_capable_and_has_reduced_motion():
    html = (ROOT / 'frontend' / 'index.html').read_text(encoding='utf-8')
    css = (ROOT / 'frontend' / 'styles.css').read_text(encoding='utf-8')
    js = (ROOT / 'frontend' / 'app.js').read_text(encoding='utf-8')
    assert 'https://' not in html  # no external runtime, font, image or stylesheet dependency
    assert 'prefers-reduced-motion' in css
    assert '#782BFF' in css and '#963DFF' in css and '#05040A' in css
    assert 'MOON_API_BASE' in js
    assert 'data-action="briefing"' in js
    assert 'data-action="cancel-research"' in js
    assert 'data-action="save-lead"' in js
    assert 'onerror=' not in html and 'onclick=' not in html
