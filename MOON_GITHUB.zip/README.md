# MOON CREATIVE — PROSPECTING INTELLIGENCE

Plataforma privada de prospecção comercial, verificação de presença digital, CRM e geração de briefings JSON individuais para Arena AI. Não é um site institucional nem um dashboard com dados de demonstração.

## O que está implementado

- Login de proprietário com senha PBKDF2, cookie `HttpOnly`, sessão expirável e CSRF nas mutações.
- Dashboard calculado do SQLite, não de contadores fixos no frontend.
- Pesquisa real por região, bairro, cidade, nicho, quantidade, seguidores e critérios.
- Descoberta por OpenStreetMap/Nominatim/Overpass sem chave; Google Places oficial quando `GOOGLE_PLACES_API_KEY` estiver configurada.
- Filtro de correspondência geográfica: uma cidade explicitamente divergente não é usada para completar a quantidade.
- Verificação de URLs públicas com proteção SSRF, status de acesso, identidade e fontes. HTTP 401/403/429 é indisponibilidade de acesso, não inatividade.
- Persistência, deduplicação, preservação de CRM, histórico de pesquisas e eventos.
- Progresso, logs e cancelamento de pesquisas; uma chamada HTTP já em curso pode terminar antes de o cancelamento ser confirmado.
- Cards com links, status, confiança, avaliações, análise, abordagem não enviada e ações.
- Leads salvos, clientes potenciais, etapas comerciais, observações, edição e exclusão.
- Briefing Arena AI individual, validado, visualizável, editável, copiável e baixável.
- Frontend Moon responsivo, abertura curta, animações moderadas e `prefers-reduced-motion`.
- Build estático para Netlify sem dependências de CDN ou segredos no navegador.

## Dados históricos incluídos

`data/seed_data.json` é uma importação real da revalidação Pets Zona Norte: **13 empresas, 62 avaliações públicas e 7 briefings**. Os status e limitações históricas são preservados. Nenhuma empresa é importada como contatada ou cliente. O seed só é importado quando o banco está vazio.

A pesquisa pública executada durante a validação da plataforma também permanece no banco local quando realizada; não há leads fictícios de fallback.

## Executar localmente

Requisitos: Python 3.11+ e Node apenas para a checagem opcional de sintaxe do JavaScript.

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements-dev.txt
python backend/server.py
```

Abra `http://localhost:8000`. No primeiro start, o servidor cria o banco e `data/OWNER_ACCESS.txt` com uma senha aleatória. Esse arquivo é local, tem permissão restrita e está fora do Git; troque a senha após o primeiro acesso. Para definir suas próprias credenciais antes do primeiro start, use `MOON_OWNER_EMAIL` e `MOON_OWNER_PASSWORD`.

O frontend também pode ser servido separadamente:

```bash
API_BASE_URL=http://localhost:8000 python3 scripts/build_frontend.py
# publique dist/ em um servidor estático; para cookies cross-site, configure CORS e SameSite conforme docs/DEPLOYMENT.md
```

## Testes efetivamente executáveis

```bash
PYTHONPATH=backend pytest -q tests
node --check frontend/app.js
MOON_OWNER_PASSWORD='sua-senha' PYTHONPATH=backend python tests/api_smoke.py
API_BASE_URL=http://localhost:8000 python3 scripts/build_frontend.py
```

Os testes unitários usam bancos temporários. O smoke test usa uma instância já iniciada, verifica autenticação/CSRF/API/JSON e restaura flags de CRM que altera. Pesquisas ao vivo dependem de rede e das políticas das fontes; falhas são registradas, não substituídas por resultados inventados.

## Integrações

| Integração | Situação sem variáveis | Configuração |
|---|---|---|
| OpenStreetMap | Ativa para descoberta pública | `MOON_OSM_CONTACT_EMAIL` recomendado; respeitar políticas e limites |
| Google Places | Não configurada | `GOOGLE_PLACES_API_KEY` no backend |
| Google Custom Search | Não configurada | `GOOGLE_CSE_API_KEY` + `GOOGLE_CSE_CX` no backend |
| IA para textos | Análise determinística ativa | `MOON_AI_API_KEY` + `MOON_AI_MODEL`; opcional `MOON_AI_BASE_URL` |
| Supabase | Não utilizado nesta versão | SQLite é o banco ativo; RLS não se aplica a SQLite |

Sem Google Places, a plataforma não afirma ter ficha ou avaliações do Google para empresas recém-descobertas. Sem uma fonte pública confiável, seguidores, atividade recente, preços, imagens e contatos ficam `null`/pendentes.

## Estrutura

```text
backend/       HTTP API, SQLite, motor de pesquisa, análise e briefing
frontend/      SPA sem framework, CSS Moon e runtime config pública
scripts/       build Netlify
data/          seed real; banco e credenciais locais são ignorados
tests/         testes unitários, regressões e smoke API
docs/          arquitetura, segurança, API e publicação
Dockerfile     opção de backend com volume persistente
netlify.toml   build e headers do frontend
```

## Publicação e segurança

Leia `docs/DEPLOYMENT.md` antes de publicar. A Netlify recebe somente `API_BASE_URL`; `ALLOWED_ORIGINS`, cookies e todas as chaves são configurados no backend. Não coloque o SQLite em um deploy efêmero sem volume nem envie `OWNER_ACCESS.txt` ao repositório.

Nenhuma mensagem comercial é enviada pela plataforma. A abordagem exibida é apenas texto sugerido, com ação de cópia sob decisão do proprietário.
