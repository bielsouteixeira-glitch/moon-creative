from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import sys
import uuid

APP = Path(__file__).resolve().parent
# Optional one-off importer; runtime never depends on these external files.
BASE = Path(os.environ.get('MOON_HISTORICAL_SOURCE_ROOT', str(APP.parent)))
sys.path.insert(0, str(APP / 'backend'))
from briefing import build_briefing

DATA = BASE / 'zn_pet_prospeccao'
NORMALIZED = BASE / 'MOON_CREATIVE_Prospeccao_Rigorosa_Pets_ZN_2026-11-01' / 'dados' / 'prospeccao_rigorosa_normalizada.json'
normalized = json.loads(NORMALIZED.read_text(encoding='utf-8'))
raw_final = json.loads((DATA / 'leads_final_2026-10-31.json').read_text(encoding='utf-8'))
raw_by_id = {x['id']: x for x in raw_final['leads'] + raw_final['reserves']}
ids = ['tridog', 'piratinhas', 'parkpetvilamaria', 'dogvilacasaverde', 'dogslife', 'casadobob', 'wedog',
       'dogfunhouse', 'dogvila', 'pataspremium', 'petvillage', 'hotelcaesvg', 'guardiao']

candidates = {lead_id: [] for lead_id in ids}
for path in DATA.rglob('*.json'):
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        continue
    def walk(node):
        if isinstance(node, dict):
            lead_id = node.get('id')
            reviews = node.get('reviews')
            if lead_id in candidates and isinstance(reviews, list) and reviews and isinstance(reviews[0], dict) and 'text' in reviews[0]:
                candidates[lead_id].append((path, node))
            for value in node.values():
                walk(value)
        elif isinstance(node, list):
            for value in node:
                walk(value)
    walk(data)

reviews = {}
for lead_id in ids:
    path, node = max(candidates[lead_id], key=lambda pair: len(pair[1]['reviews']))
    raw = raw_by_id[lead_id]
    fallback = raw['google']['reviews_url'] if 'google' in raw else raw['maps_url']
    source = node.get('reviews_tab_url') or fallback
    items = []
    for review in node['reviews']:
        items.append({
            'author': review.get('author'), 'rating_label': review.get('rating_label'),
            'date_display': review.get('date_display'), 'text': review.get('text'),
            'review_id': review.get('review_id'), 'source_url': source,
        })
    reviews[lead_id] = {'items': items, 'source': source, 'collected_at': node.get('collected_at') or '2026-10-30'}
assert sum(len(x['items']) for x in reviews.values()) == 62


def confidence(lead):
    score = 20
    if lead.get('maps_status') == 'VERIFICADO': score += 25
    if lead.get('whatsapp_status') == 'VERIFICADO': score += 25
    if lead.get('instagram_status') == 'VERIFICADO': score += 10
    elif lead.get('instagram_url'): score += 5
    if lead.get('address'): score += 10
    if lead.get('last_post_date'): score += 5
    return min(score, 100)


def link_sources(platform, obj):
    result = []
    for s in obj.get('fontes') or []:
        result.append({'tipo': f'{platform} — {s.get("tipo")}', 'url': s.get('url'), 'data': s.get('data'), 'resultado': s.get('resultado')})
    return result


def problem(platform, obj):
    if obj.get('status') in {'INDISPONÍVEL', 'INCONSISTENTE', 'NÃO VERIFICADO'}:
        return {'plataforma': platform, 'url': obj.get('url'), 'status': obj.get('status'), 'observacao': obj.get('observacao')}
    return None


leads = []
for item in normalized['leads_validados']:
    lead_id = item['id_lead']
    sources = []
    problems = []
    for platform, key in [('Google Maps', 'google_maps'), ('Instagram', 'instagram'), ('WhatsApp', 'whatsapp'), ('Site', 'site_atual')]:
        sources.extend(link_sources(platform, item[key]))
        p = problem(platform, item[key])
        if p: problems.append(p)
    other = []
    for link in item.get('links_adicionais') or []:
        other.append({'plataforma': link.get('plataforma'), 'url': link.get('url'), 'status': link.get('status'), 'fonte': '; '.join((s.get('tipo') or '') for s in link.get('fontes') or []), 'observacao': link.get('observacao')})
        sources.extend(link_sources(link.get('plataforma'), link))
    last = item['instagram'].get('ultima_publicacao_publica') or {}
    lead = {
        'id': str(uuid.uuid5(uuid.NAMESPACE_URL, 'moon-creative:' + lead_id)),
        'name': item['nome_fantasia'], 'segment': 'Creches e hotéis para pets', 'description': None,
        'neighborhood': item['bairro'], 'city': 'São Paulo', 'region': 'Zona Norte', 'address': item['endereco'],
        'image_url': None, 'instagram_url': item['instagram'].get('url'), 'instagram_status': item['instagram'].get('status'),
        'followers': item['instagram'].get('seguidores_observados'), 'last_post_date': last.get('data'), 'post_frequency': None,
        'whatsapp_number': item['whatsapp'].get('numero_e164'), 'whatsapp_url': item['whatsapp'].get('url'), 'whatsapp_status': item['whatsapp'].get('status'),
        'site_url': item['site_atual'].get('url'), 'site_status': item['site_atual'].get('status'),
        'maps_url': item['google_maps'].get('url'), 'maps_status': item['google_maps'].get('status'),
        'other_links': other, 'services': [x['servico'] for x in item.get('servicos_confirmados') or []],
        'products': [], 'prices': [], 'hours': None, 'order_methods': [], 'differentials': [],
        'strengths': [item['sinais_atividade']['resumo']], 'opportunities': [item['oportunidade_comercial']['justificativa']],
        'commercial_analysis': item['oportunidade_comercial']['justificativa'] + ' ' + item['objetivo_comercial'],
        'approach_message': item['abordagem_inicial_sugerida']['mensagem_nao_enviada'],
        'rating': item['avaliacoes_google']['nota'], 'review_count': item['avaliacoes_google']['quantidade'],
        'reviews': reviews[lead_id]['items'], 'opportunity_level': item['oportunidade_comercial']['nivel'],
        'qualification_status': 'VERIFICADO', 'saved': True, 'potential_client': False,
        'commercial_stage': 'Lead analisado', 'project_status': 'BRIEFING PRONTO', 'notes': '',
        'logo': None, 'photos': [], 'videos': [], 'menu_catalog': None, 'visual_identity': None,
        'materials_pending': ['Logotipo, paleta, fotos, vídeos e autorizações de uso não fornecidos.'],
        'target_audience': None, 'visual_concept': item.get('direcao_arte_sugerida'), 'palette': [],
        'sections': item['conceito_de_site_sugerido'].get('secoes') or [], 'features': item.get('funcionalidades_recomendadas') or [],
        'site_objective': item.get('objetivo_comercial'), 'sources': sources + [{'tipo': 'Avaliações do Google', 'url': reviews[lead_id]['source'], 'data': reviews[lead_id]['collected_at'], 'resultado': f"{len(reviews[lead_id]['items'])} cartões públicos preservados no histórico."}],
        'unconfirmed': item.get('pendencias') or [], 'problem_links': problems,
        'verification_notes': ['Importado da revalidação rigorosa de 01/11/2026.', item['instagram'].get('observacao')],
        'research_date': '2026-11-01T12:00:00-03:00', 'raw': {'origin': 'MOON_CREATIVE_Prospeccao_Rigorosa_Pets_ZN_2026-11-01', 'decision': 'VALIDADO'},
    }
    lead['confidence'] = confidence(lead)
    lead['briefing'] = build_briefing(lead)
    leads.append(lead)

neighborhood_fallback = {'dogvila': 'Santana', 'guardiao': 'Vila Gustavo'}
for item in normalized['nao_promovidos']:
    lead_id = item['id_lead']
    raw = raw_by_id[lead_id]
    links = {x['plataforma']: x for x in item['links_auditados']}
    maps = links.get('Google Maps') or {'url': raw.get('maps_url') or raw.get('google', {}).get('profile_url'), 'status': 'VERIFICADO', 'fontes': []}
    ig = links.get('Instagram') or {'url': None, 'status': 'NÃO VERIFICADO', 'fontes': []}
    wa = links.get('WhatsApp') or {'url': None, 'status': 'NÃO VERIFICADO', 'fontes': []}
    site = links.get('Site') or {'url': None, 'status': 'NÃO VERIFICADO', 'fontes': []}
    if 'google' in raw:
        address = raw.get('address')
        rating = raw['google'].get('rating_value')
        review_count = raw['google'].get('review_count')
        neighborhood = raw.get('neighborhood')
        wa_number = raw.get('contact', {}).get('number_e164')
        raw_ig = raw.get('instagram') or {}
        followers = raw_ig.get('followers_observed')
        last_post = (raw_ig.get('last_public_post') or {}).get('date_local')
    else:
        address = raw.get('address')
        rating = float(str(raw.get('rating')).replace(',', '.')) if raw.get('rating') else None
        review_count = int(re.search(r'\d+', raw.get('reviews') or '0').group())
        neighborhood = neighborhood_fallback.get(lead_id)
        wa_number = raw.get('phone')
        followers = None
        last_post = None
    site_url = site.get('url')
    site_status = site.get('status')
    if lead_id in {'pataspremium', 'petvillage'}:
        site_url = None  # Homonyms stay only as explicitly labelled audit links.
    sources = []
    problems = []
    core_urls = set()
    for platform, obj in [('Google Maps', maps), ('Instagram', ig), ('WhatsApp', wa), ('Site', site)]:
        core_urls.add(obj.get('url'))
        sources.extend(link_sources(platform, obj))
        p = problem(platform, obj)
        if p: problems.append(p)
    other = []
    for link in item['links_auditados']:
        if link.get('url') in core_urls and link.get('plataforma') in {'Google Maps', 'Instagram', 'WhatsApp', 'Site'}:
            continue
        other.append({'plataforma': link.get('plataforma'), 'url': link.get('url'), 'status': link.get('status'), 'fonte': '; '.join((s.get('tipo') or '') for s in link.get('fontes') or []), 'observacao': link.get('observacao')})
        sources.extend(link_sources(link.get('plataforma'), link))
    lead = {
        'id': str(uuid.uuid5(uuid.NAMESPACE_URL, 'moon-creative:' + lead_id)),
        'name': item['nome_fantasia'], 'segment': 'Creches e hotéis para pets', 'description': None,
        'neighborhood': neighborhood, 'city': 'São Paulo', 'region': 'Zona Norte', 'address': address,
        'image_url': None, 'instagram_url': ig.get('url'), 'instagram_status': ig.get('status'),
        'followers': followers, 'last_post_date': last_post, 'post_frequency': None,
        'whatsapp_number': wa_number, 'whatsapp_url': wa.get('url'), 'whatsapp_status': wa.get('status'),
        'site_url': site_url, 'site_status': site_status, 'maps_url': maps.get('url'), 'maps_status': maps.get('status'),
        'other_links': other, 'services': raw.get('services') if isinstance(raw.get('services'), list) else ([raw.get('category')] if raw.get('category') else []),
        'products': [], 'prices': [], 'hours': None, 'order_methods': [], 'differentials': [],
        'strengths': [], 'opportunities': [], 'commercial_analysis': item['motivo'] + ' Próximo passo: ' + item['proximo_passo'],
        'approach_message': None, 'rating': rating, 'review_count': review_count, 'reviews': reviews[lead_id]['items'],
        'opportunity_level': None, 'qualification_status': 'NÃO QUALIFICADO' if item['decisao'] == 'EXCLUÍDO' else 'PARCIALMENTE VERIFICADO',
        'saved': False, 'potential_client': False, 'commercial_stage': 'Lead analisado', 'project_status': 'NÃO INICIADO', 'notes': '',
        'logo': None, 'photos': [], 'videos': [], 'menu_catalog': None, 'visual_identity': None,
        'materials_pending': [], 'target_audience': None, 'visual_concept': None, 'palette': [], 'sections': [], 'features': [],
        'site_objective': None, 'sources': sources + [{'tipo': 'Avaliações do Google', 'url': reviews[lead_id]['source'], 'data': reviews[lead_id]['collected_at'], 'resultado': f"{len(reviews[lead_id]['items'])} cartões públicos preservados no histórico."}],
        'unconfirmed': [item['motivo']], 'problem_links': problems,
        'verification_notes': [item['motivo'], item['proximo_passo'], 'Não promovido na seleção rigorosa; não usar como lead validado sem nova verificação.'],
        'research_date': '2026-11-01T12:00:00-03:00', 'raw': {'origin': 'MOON_CREATIVE_Prospeccao_Rigorosa_Pets_ZN_2026-11-01', 'decision': item['decisao']}, 'briefing': None,
    }
    lead['confidence'] = confidence(lead)
    leads.append(lead)

seed = {
    'search': {
        'created_at': '2026-11-01T12:00:00-03:00', 'region': 'Zona Norte', 'neighborhood': None,
        'city': 'São Paulo', 'niche': 'Creches e hotéis para pets', 'desired_count': len(leads),
        'min_followers': 900, 'max_followers': 10000,
        'criteria': {'origin': 'Revalidação rigorosa importada', 'notes': 'Dados reais da prospecção anterior; não é demonstração.'},
        'provider': 'historical_import',
    },
    'leads': leads,
}
out = APP / 'data' / 'seed_data.json'
out.write_text(json.dumps(seed, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
assert len(leads) == 13
assert sum(len(x['reviews']) for x in leads) == 62
assert sum(1 for x in leads if x['briefing']) == 7
print({'output': str(out), 'leads': len(leads), 'reviews': sum(len(x['reviews']) for x in leads), 'briefings': sum(1 for x in leads if x['briefing']), 'bytes': out.stat().st_size})
